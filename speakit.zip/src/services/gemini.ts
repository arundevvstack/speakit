import { GoogleGenAI, Type, Modality, ThinkingLevel } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const LEVEL_DESCRIPTIONS = {
  beginner: "Focus on basic grammar, simple sentences, and common everyday vocabulary. Use clear, slow, and encouraging language. Avoid complex idioms or technical jargon.",
  intermediate: "Focus on natural phrasing, common idioms, and more complex sentence structures. Encourage the user to express opinions and provide more detailed explanations. Use a natural speaking pace.",
  advanced: "Focus on sophisticated vocabulary, professional/academic tone, subtle grammatical nuances, and advanced idioms. Challenge the user with complex topics and expect high-level reasoning and flow."
};

export const COACH_SYSTEM_INSTRUCTION = (level: string) => `
You are an English speaking coach.
The user is at the ${level} level. 
${LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || ""}

The user will speak a sentence. Your job is to:
1. Correct grammar: Fix errors while keeping the user's intent.
2. Improve vocabulary: Suggest words that are slightly above their current level to help them grow.
3. Check natural fluency: Suggest more natural ways to say the same thing.
4. Provide phonetic pronunciation: Use IPA or a simple phonetic guide for the corrected version.
5. Provide a professional business version: How would this be said in a formal workplace?
6. Highlight key vocabulary: Pick 2-3 important words or phrases from the correction.
7. Give a level-appropriate explanation: Explain WHY the changes were made in a way the user can understand.

You MUST respond in JSON format with the following structure:
{
  "original": "the original sentence",
  "corrected": "the grammatically correct version",
  "improved": "a more natural/advanced version",
  "business": "a professional business communication version",
  "pronunciation": "phonetic pronunciation of the corrected version",
  "vocabulary": ["word1", "word2"],
  "feedback": "a short, ${level}-friendly explanation of the changes"
}
`;

export const CONVERSATION_SYSTEM_INSTRUCTION = (level: string, scenario?: string, objectives?: string[]) => `
You are a friendly English conversation partner.
The user is at the ${level} level.
${LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || ""}

- Talk like a real human, but adapt your complexity to the user's level.
- Keep responses relatively short to encourage the user to speak more.
- Ask engaging follow-up questions.
- If the user makes a major mistake, gently correct it in your response, but keep the conversation flowing.
${scenario ? `Scenario: ${scenario}` : 'Scenario: casual conversation'}
${objectives ? `Learning Objectives for this session:
${objectives.map((obj, i) => `${i + 1}. ${obj}`).join('\n')}
Try to guide the user towards these objectives naturally.` : ''}
Start the conversation.
`;

export async function getCorrection(text: string, level: string = 'beginner', retries = 2, delay = 500): Promise<any> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: text,
      config: {
        systemInstruction: COACH_SYSTEM_INSTRUCTION(level),
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            original: { type: Type.STRING },
            corrected: { type: Type.STRING },
            improved: { type: Type.STRING },
            business: { type: Type.STRING },
            pronunciation: { type: Type.STRING },
            vocabulary: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            feedback: { type: Type.STRING },
          },
          required: ["original", "corrected", "improved", "business", "pronunciation", "vocabulary", "feedback"],
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    if (err.status === 429 && retries > 0) {
      console.warn(`Rate limit exceeded in getCorrection, retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return getCorrection(text, level, retries - 1, delay * 2);
    }
    console.error('Error in getCorrection:', err);
    throw err;
  }
}

export interface Exercise {
  type: 'roleplay' | 'drill';
  title: string;
  description: string;
  scenario: string;
  objectives: string[];
}

export async function getExerciseSuggestions(level: string): Promise<Exercise[]> {
  const levelDesc = LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || "";
  const prompt = `Suggest 4 structured English speaking exercises for a ${level} level student.
  ${levelDesc}
  Include 2 role-playing scenarios and 2 pronunciation/fluency drills.
  For each exercise, provide 3 specific learning objectives that are challenging but achievable for a ${level} level student.
  
  Respond in JSON:
  [
    {
      "type": "roleplay",
      "title": "Short title",
      "description": "Brief instruction for the user",
      "scenario": "Detailed scenario description for the AI",
      "objectives": ["Objective 1", "Objective 2", "Objective 3"]
    }
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING, enum: ['roleplay', 'drill'] },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              scenario: { type: Type.STRING },
              objectives: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
            },
            required: ["type", "title", "description", "scenario", "objectives"],
          },
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    console.error('Error in getExerciseSuggestions:', err);
    return [];
  }
}

export async function getConversationResponse(text: string, level: string = 'beginner', history: { role: 'user' | 'ai', text: string }[] = [], scenario?: string, objectives?: string[], retries = 2, delay = 500): Promise<string> {
  try {
    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: CONVERSATION_SYSTEM_INSTRUCTION(level, scenario, objectives),
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
      },
      history: history.map(h => ({
        role: h.role === 'user' ? 'user' : 'model',
        parts: [{ text: h.text }]
      }))
    });
    
    const response = await chat.sendMessage({ message: text });
    return response.text;
  } catch (err: any) {
    if (err.status === 429 && retries > 0) {
      console.warn(`Rate limit exceeded in getConversationResponse, retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return getConversationResponse(text, level, history, scenario, objectives, retries - 1, delay * 2);
    }
    console.error('Error in getConversationResponse:', err);
    throw err;
  }
}

export async function getSpeechResponse(text: string, retries = 2, delay = 500): Promise<string | null> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const parts = response.candidates?.[0]?.content?.parts;
    if (!parts) {
      console.error('No parts in response:', response);
      return null;
    }

    const audioPart = parts.find(part => part.inlineData);
    if (audioPart && audioPart.inlineData) {
      return audioPart.inlineData.data;
    }

    const textPart = parts.find(part => part.text);
    if (textPart) {
      console.warn('Model returned text instead of audio:', textPart.text);
    } else {
      console.error('No audio or text part found in response:', response);
    }
    return null;
  } catch (err: any) {
    if (err.status === 429 && retries > 0) {
      console.warn(`Rate limit exceeded, retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
      return getSpeechResponse(text, retries - 1, delay * 2);
    }
    console.error('Error in getSpeechResponse:', err);
    throw err;
  }
}

export async function getVocabularyPractice(word: string, level: string = 'beginner', retries = 2, delay = 500): Promise<{ sentence: string, challenge: string, answer: string }> {
  const levelDesc = LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || "";
  const prompt = `Create a practice challenge for the English vocabulary word: "${word}".
  The user is at the ${level} level.
  ${levelDesc}
  
  Provide:
  1. A natural, level-appropriate example sentence using the word.
  2. A fill-in-the-blank version of that sentence.
  3. The correct word to fill in (which is "${word}").
  
  Respond in JSON:
  {
    "sentence": "The full example sentence.",
    "challenge": "The sentence with the word replaced by ____.",
    "answer": "${word}"
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentence: { type: Type.STRING },
            challenge: { type: Type.STRING },
            answer: { type: Type.STRING },
          },
          required: ["sentence", "challenge", "answer"],
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    if (err.status === 429 && retries > 0) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return getVocabularyPractice(word, level, retries - 1, delay * 2);
    }
    throw err;
  }
}

export async function getVocabularyList(level: string): Promise<{ word: string, definition: string, example: string }[]> {
  const levelDesc = LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || "";
  const prompt = `Suggest 10 useful English vocabulary words, idioms, or phrasal verbs for a ${level} level student.
  ${levelDesc}
  The words should be practical and help the user move towards the next proficiency level.
  For each, provide a brief definition and a natural example sentence.
  
  Respond in JSON:
  [
    {
      "word": "word",
      "definition": "brief definition",
      "example": "example sentence"
    }
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              word: { type: Type.STRING },
              definition: { type: Type.STRING },
              example: { type: Type.STRING },
            },
            required: ["word", "definition", "example"],
          },
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    console.error('Error in getVocabularyList:', err);
    return [];
  }
}

export async function getPronunciationDrill(level: string): Promise<{ sentence: string, focus: string, phonetic: string, tip: string }[]> {
  const levelDesc = LEVEL_DESCRIPTIONS[level as keyof typeof LEVEL_DESCRIPTIONS] || "";
  const prompt = `Suggest 5 English sentences for pronunciation practice for a ${level} level student.
  ${levelDesc}
  Focus on common difficulties for this level, such as minimal pairs, word stress, intonation, or connected speech.
  
  Respond in JSON:
  [
    {
      "sentence": "The sentence to practice",
      "focus": "What this sentence focuses on (e.g., 'th' sound, word stress)",
      "phonetic": "Simple phonetic guide",
      "tip": "A small tip or explanation related to the specific sounds or intonation patterns that the drill focuses on."
    }
  ]`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              sentence: { type: Type.STRING },
              focus: { type: Type.STRING },
              phonetic: { type: Type.STRING },
              tip: { type: Type.STRING },
            },
            required: ["sentence", "focus", "phonetic", "tip"],
          },
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    console.error('Error in getPronunciationDrill:', err);
    return [];
  }
}

export async function analyzePronunciation(target: string, actual: string): Promise<{ 
  score: number, 
  accuracy: number,
  fluency: number,
  completeness: number,
  feedback: string, 
  improvements: string[] 
}> {
  const prompt = `Target sentence: "${target}"
  User said: "${actual}"
  
  Analyze the user's pronunciation based on the transcript. 
  Note: The transcript might have errors if the pronunciation was very off.
  
  Provide:
  1. An overall score from 0-100.
  2. An accuracy score (how well they pronounced individual words).
  3. A fluency score (rhythm and flow).
  4. A completeness score (did they say all the words?).
  5. A brief feedback message.
  6. Specific areas for improvement.
  
  Respond in JSON:
  {
    "score": 85,
    "accuracy": 80,
    "fluency": 90,
    "completeness": 100,
    "feedback": "Great job! You were very clear.",
    "improvements": ["Watch the 'th' sound in 'think'", "Stress the second syllable in 'record'"]
  }`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            accuracy: { type: Type.NUMBER },
            fluency: { type: Type.NUMBER },
            completeness: { type: Type.NUMBER },
            feedback: { type: Type.STRING },
            improvements: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
          },
          required: ["score", "accuracy", "fluency", "completeness", "feedback", "improvements"],
        },
      },
    });
    return JSON.parse(response.text);
  } catch (err: any) {
    console.error('Error in analyzePronunciation:', err);
    return { 
      score: 0, 
      accuracy: 0,
      fluency: 0,
      completeness: 0,
      feedback: "Error analyzing pronunciation.", 
      improvements: [] 
    };
  }
}
