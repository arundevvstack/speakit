import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, MessageSquare, History, Settings, Play, Pause, RotateCcw, Sparkles, ChevronRight, Volume2, RefreshCw, BookOpen, CheckCircle2, AlertCircle, TrendingUp, Target, Activity, Zap } from 'lucide-react';
import { cn } from './lib/utils';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { 
  getCorrection, 
  getConversationResponse, 
  getSpeechResponse, 
  getVocabularyPractice, 
  getExerciseSuggestions,
  getVocabularyList,
  getPronunciationDrill,
  analyzePronunciation
} from './services/gemini';
import ReactMarkdown from 'react-markdown';

// --- Types ---
interface Feedback {
  original: string;
  corrected: string;
  improved: string;
  business: string;
  pronunciation: string;
  vocabulary: string[];
  explanation: string;
}

interface ChatMessage {
  role: 'user' | 'ai';
  text: string;
}

interface Exercise {
  type: 'roleplay' | 'drill';
  title: string;
  description: string;
  scenario: string;
  objectives: string[];
}

interface ChatSession {
  id: string;
  title: string;
  timestamp: number;
  history: ChatMessage[];
  level: 'beginner' | 'intermediate' | 'advanced';
}

interface VocabularyItem {
  word: string;
  definition: string;
  example: string;
}

interface PronunciationDrillItem {
  sentence: string;
  focus: string;
  phonetic: string;
  tip: string;
}

interface PronunciationAnalysis {
  score: number;
  accuracy: number;
  fluency: number;
  completeness: number;
  feedback: string;
  improvements: string[];
  userTranscript?: string;
}

interface PronunciationHistoryItem {
  id: string;
  timestamp: number;
  sentence: string;
  analysis: PronunciationAnalysis;
}

interface ActivityLog {
  id: string;
  timestamp: number;
  duration: number; // in seconds
  type: 'coach' | 'chat' | 'exercise' | 'vocabulary' | 'pronunciation';
}

interface LearningGoal {
  type: 'sessions' | 'minutes';
  period: 'weekly' | 'monthly';
  target: number;
}

interface UserGoals {
  weekly: LearningGoal | null;
  monthly: LearningGoal | null;
}

const CONVERSATION_STARTERS = [
  { label: "Daily Life", text: "Tell me about your typical daily routine." },
  { label: "Hobbies", text: "What are some hobbies you enjoy in your free time?" },
  { label: "Travel", text: "If you could travel anywhere in the world, where would you go?" },
  { label: "Work/Study", text: "What do you do for a living, or what are you studying?" },
  { label: "Food", text: "What's your favorite type of cuisine and why?" },
  { label: "Future Goals", text: "What are some of your goals for the next five years?" }
];

// --- Components ---

export default function App() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<'coach' | 'chat' | 'exercise' | 'vocabulary' | 'pronunciation'>('coach');
  const [userLevel, setUserLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('beginner');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [manualInput, setManualInput] = useState('');
  const [showManualInput, setShowManualInput] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<PermissionState | 'unknown'>('unknown');
  const [audioData, setAudioData] = useState<number[]>(new Array(32).fill(0));
  const [practiceChallenge, setPracticeChallenge] = useState<{ word: string, challenge: string, sentence: string, answer: string } | null>(null);
  const [practiceInput, setPracticeInput] = useState('');
  const [isPracticeLoading, setIsPracticeLoading] = useState(false);
  const [practiceFeedback, setPracticeFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [exerciseSuggestions, setExerciseSuggestions] = useState<Exercise[]>([]);
  const [currentExercise, setCurrentExercise] = useState<Exercise | null>(null);
  const [dailyChallenge, setDailyChallenge] = useState<Exercise | null>(null);
  const [isLoadingExercises, setIsLoadingExercises] = useState(false);
  const [exerciseDifficulty, setExerciseDifficulty] = useState<'beginner' | 'intermediate' | 'advanced' | 'all'>('all');
  const [selectedScenario, setSelectedScenario] = useState<string | null>(null);

  // Vocabulary Mode State
  const [vocabularyList, setVocabularyList] = useState<VocabularyItem[]>([]);
  const [isLoadingVocabulary, setIsLoadingVocabulary] = useState(false);
  
  // Pronunciation Mode State
  const [pronunciationDrills, setPronunciationDrills] = useState<PronunciationDrillItem[]>([]);
  const [currentDrill, setCurrentDrill] = useState<PronunciationDrillItem | null>(null);
  const [isLoadingDrills, setIsLoadingDrills] = useState(false);
  const [pronunciationAnalysis, setPronunciationAnalysis] = useState<PronunciationAnalysis | null>(null);
  const [isAnalyzingPronunciation, setIsAnalyzingPronunciation] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [pronunciationHistory, setPronunciationHistory] = useState<PronunciationHistoryItem[]>([]);
  const [showPronunciationHistory, setShowPronunciationHistory] = useState(false);
  const [showPronunciationProgress, setShowPronunciationProgress] = useState(false);

  // Goals & Activity State
  const [goals, setGoals] = useState<UserGoals>({
    weekly: { type: 'minutes', period: 'weekly', target: 30 },
    monthly: { type: 'sessions', period: 'monthly', target: 20 }
  });
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [showGoalsProgress, setShowGoalsProgress] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cachedVocabulary, setCachedVocabulary] = useState<VocabularyItem[]>([]);
  const [cachedDrills, setCachedDrills] = useState<PronunciationDrillItem[]>([]);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const recordingStartTimeRef = useRef<number | null>(null);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory]);

  useEffect(() => {
    if (isRecording) {
      setTranscript('');
      startAudioAnalysis();
      recordingStartTimeRef.current = Date.now();
      // Force a restart of recognition to clear buffer for the new recording
      if (recognitionRef.current && isRecognitionRunningRef.current) {
        isManualRestartRef.current = true;
        recognitionRef.current.stop();
      }
    } else {
      stopAudioAnalysis();
    }
    return () => {
      stopAudioAnalysis();
    };
  }, [isRecording]);

  useEffect(() => {
    if (!isRecording && transcript.trim()) {
      const duration = recordingStartTimeRef.current ? Math.round((Date.now() - recordingStartTimeRef.current) / 1000) : 0;
      processInput(transcript, duration);
      setTranscript('');
      recordingStartTimeRef.current = null;
    }
  }, [isRecording]);

  const startAudioAnalysis = async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setError('Microphone access is not supported in this environment.');
      setIsRecording(false);
      return;
    }
    try {
      // Check if any audio input devices are available
      const devices = await navigator.mediaDevices.enumerateDevices();
      const audioDevices = devices.filter(device => device.kind === 'audioinput');
      if (audioDevices.length === 0) {
        throw new Error('Requested device not found');
      }
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();
      audioContextRef.current = audioContext;

      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 64; // Smaller FFT for fewer bars
      analyserRef.current = analyser;

      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const update = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        // Normalize and set data
        const normalizedData = Array.from(dataArray).map(v => v / 255);
        setAudioData(normalizedData);
        animationFrameRef.current = requestAnimationFrame(update);
      };

      update();
    } catch (err: any) {
      console.error('Error starting audio analysis:', err);
      setIsRecording(false);
      if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setError('No microphone found. Please connect a microphone and try again.');
      } else if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError('Microphone access denied. Please click the lock icon in your browser address bar and allow microphone access for this site.');
      } else {
        setError(`Error starting audio: ${err.message}`);
      }
    }
  };

  const stopAudioAnalysis = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(err => console.error('Error closing AudioContext:', err));
    }
    audioContextRef.current = null;
    analyserRef.current = null;
    setAudioData(new Array(32).fill(0));
  };

  useEffect(() => {
    if (navigator.permissions && (navigator.permissions as any).query) {
      navigator.permissions.query({ name: 'microphone' as any }).then((status) => {
        setPermissionStatus(status.state);
        status.onchange = () => setPermissionStatus(status.state);
      }).catch(err => console.warn('Permissions API not supported for microphone:', err));
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    const savedSessions = localStorage.getItem('speakflow_sessions');
    if (savedSessions) {
      try {
        setSessions(JSON.parse(savedSessions));
      } catch (e) {
        console.error('Failed to parse saved sessions:', e);
      }
    }
    const savedPronunciationHistory = localStorage.getItem('speakflow_pronunciation_history');
    if (savedPronunciationHistory) {
      try {
        setPronunciationHistory(JSON.parse(savedPronunciationHistory));
      } catch (e) {
        console.error('Failed to parse saved pronunciation history:', e);
      }
    }
    const savedGoals = localStorage.getItem('speakflow_goals');
    if (savedGoals) {
      try {
        setGoals(JSON.parse(savedGoals));
      } catch (e) {
        console.error('Failed to parse saved goals:', e);
      }
    }
    const savedActivityLogs = localStorage.getItem('speakflow_activity_logs');
    if (savedActivityLogs) {
      try {
        setActivityLogs(JSON.parse(savedActivityLogs));
      } catch (e) {
        console.error('Failed to parse saved activity logs:', e);
      }
    }
    const savedVocab = localStorage.getItem('speakflow_cached_vocab');
    if (savedVocab) {
      try {
        setCachedVocabulary(JSON.parse(savedVocab));
      } catch (e) {
        console.error('Failed to parse saved vocab:', e);
      }
    }
    const savedDrills = localStorage.getItem('speakflow_cached_drills');
    if (savedDrills) {
      try {
        setCachedDrills(JSON.parse(savedDrills));
      } catch (e) {
        console.error('Failed to parse saved drills:', e);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('speakflow_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem('speakflow_pronunciation_history', JSON.stringify(pronunciationHistory));
  }, [pronunciationHistory]);

  useEffect(() => {
    localStorage.setItem('speakflow_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('speakflow_activity_logs', JSON.stringify(activityLogs));
  }, [activityLogs]);

  useEffect(() => {
    localStorage.setItem('speakflow_cached_vocab', JSON.stringify(cachedVocabulary));
  }, [cachedVocabulary]);

  useEffect(() => {
    localStorage.setItem('speakflow_cached_drills', JSON.stringify(cachedDrills));
  }, [cachedDrills]);

  const getLevenshteinDistance = (a: string, b: string): number => {
    const matrix = Array.from({ length: a.length + 1 }, () => Array(b.length + 1).fill(0));
    for (let i = 0; i <= a.length; i++) matrix[i][0] = i;
    for (let j = 0; j <= b.length; j++) matrix[0][j] = j;
    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1].toLowerCase() === b[j - 1].toLowerCase() ? 0 : 1;
        matrix[i][j] = Math.min(matrix[i - 1][j] + 1, matrix[i][j - 1] + 1, matrix[i - 1][j - 1] + cost);
      }
    }
    return matrix[a.length][b.length];
  };

  const analyzePronunciationOffline = (target: string, actual: string): PronunciationAnalysis => {
    const targetWords = target.toLowerCase().replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").split(/\s+/);
    const actualWords = actual.toLowerCase().replace(/[.,/#!$%^&*;:{}=\-_`~()]/g, "").split(/\s+/);
    
    let matchedCount = 0;
    actualWords.forEach(word => {
      if (targetWords.includes(word)) matchedCount++;
    });

    const accuracy = Math.round((matchedCount / Math.max(targetWords.length, actualWords.length)) * 100);
    const distance = getLevenshteinDistance(target, actual);
    const maxLen = Math.max(target.length, actual.length);
    const score = Math.max(0, Math.round(((maxLen - distance) / maxLen) * 100));

    return {
      score,
      accuracy,
      fluency: score, // Simplified for offline
      completeness: Math.round((actualWords.length / targetWords.length) * 100),
      feedback: "Offline analysis based on text similarity. Connect to internet for detailed AI feedback.",
      improvements: accuracy < 80 ? ["Try to speak more clearly", "Check individual word sounds"] : ["Good effort!"]
    };
  };

  useEffect(() => {
    if (mode === 'chat' && chatHistory.length === 0 && !currentSessionId) {
      const initialMsg: ChatMessage = { role: 'ai', text: `Hello! I'm your ${userLevel} level English partner. How are you feeling today?` };
      setChatHistory([initialMsg]);
      
      // Create a new session automatically if none exists
      const newSession: ChatSession = {
        id: crypto.randomUUID(),
        title: 'New Conversation',
        timestamp: Date.now(),
        history: [initialMsg],
        level: userLevel
      };
      setSessions(prev => [newSession, ...prev]);
      setCurrentSessionId(newSession.id);
    }
    
    if (mode === 'vocabulary') {
      fetchVocabulary();
    }
    if (mode === 'pronunciation') {
      fetchDrills();
    }
  }, [mode, userLevel]);

  const fetchVocabulary = async () => {
    if (!isOnline) {
      if (cachedVocabulary.length > 0) {
        setVocabularyList(cachedVocabulary);
      } else {
        setError('No cached vocabulary available. Please connect to the internet to download words.');
      }
      return;
    }

    setIsLoadingVocabulary(true);
    try {
      const list = await getVocabularyList(userLevel);
      setVocabularyList(list);
      setCachedVocabulary(list);
    } catch (err) {
      console.error('Failed to fetch vocabulary:', err);
    } finally {
      setIsLoadingVocabulary(false);
    }
  };

  const getProgress = (period: 'weekly' | 'monthly') => {
    const goal = goals[period];
    if (!goal) return null;

    const now = new Date();
    const startOfPeriod = new Date();
    if (period === 'weekly') {
      const day = now.getDay();
      const diff = now.getDate() - day + (day === 0 ? -6 : 1); // Monday
      startOfPeriod.setDate(diff);
      startOfPeriod.setHours(0, 0, 0, 0);
    } else {
      startOfPeriod.setDate(1);
      startOfPeriod.setHours(0, 0, 0, 0);
    }

    const logsInPeriod = activityLogs.filter(log => log.timestamp >= startOfPeriod.getTime());

    if (goal.type === 'minutes') {
      const totalSeconds = logsInPeriod.reduce((acc, log) => acc + log.duration, 0);
      const current = Math.round(totalSeconds / 60);
      return { current, target: goal.target, unit: 'min' };
    } else {
      const current = logsInPeriod.length;
      return { current, target: goal.target, unit: 'sessions' };
    }
  };

  const fetchDrills = async () => {
    if (!isOnline) {
      if (cachedDrills.length > 0) {
        setPronunciationDrills(cachedDrills);
        setCurrentDrill(cachedDrills[0]);
      } else {
        setError('No cached drills available. Please connect to the internet to download drills.');
      }
      return;
    }

    setIsLoadingDrills(true);
    try {
      const drills = await getPronunciationDrill(userLevel);
      setPronunciationDrills(drills);
      setCachedDrills(drills);
      if (drills.length > 0) setCurrentDrill(drills[0]);
    } catch (err) {
      console.error('Failed to fetch drills:', err);
    } finally {
      setIsLoadingDrills(false);
    }
  };

  // Update current session whenever chat history changes
  useEffect(() => {
    if (currentSessionId && chatHistory.length > 0) {
      setSessions(prev => prev.map(s => 
        s.id === currentSessionId 
          ? { ...s, history: chatHistory, timestamp: Date.now(), title: chatHistory.find(m => m.role === 'user')?.text.slice(0, 30) || s.title } 
          : s
      ));
    }
  }, [chatHistory, currentSessionId]);

  const recognitionRef = useRef<any>(null);
  const isRecognitionRunningRef = useRef(false);
  const restartTimerRef = useRef<NodeJS.Timeout | null>(null);

  const isRecordingRef = useRef(false);
  const isManualRestartRef = useRef(false);

  useEffect(() => {
    isRecordingRef.current = isRecording;
  }, [isRecording]);

  const lastErrorRef = useRef<string | null>(null);

  useEffect(() => {
    // Initialize Speech Recognition
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onstart = () => {
        isRecognitionRunningRef.current = true;
        lastErrorRef.current = null;
        if (restartTimerRef.current) {
          clearTimeout(restartTimerRef.current);
          restartTimerRef.current = null;
        }
      };

      recognitionRef.current.onresult = (event: any) => {
        const transcriptText = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        
        if (!isRecordingRef.current && transcriptText.toLowerCase().includes('achu')) {
          setError(null);
          setTranscript('');
          setIsRecording(true);
          // Stop to clear buffer, onend will handle restart
          isManualRestartRef.current = true;
          recognitionRef.current?.stop();
        } else if (isRecordingRef.current) {
          setTranscript(transcriptText);
        }
      };

      recognitionRef.current.onend = () => {
        isRecognitionRunningRef.current = false;
        
        // If it was a manual restart for wake-word or a no-speech error, we want to restart immediately
        const restartDelay = (isManualRestartRef.current || lastErrorRef.current === 'no-speech') ? 50 : 1000;
        isManualRestartRef.current = false;
        lastErrorRef.current = null;

        // Only schedule a restart if one isn't already pending
        if (recognitionRef.current && !restartTimerRef.current) {
          restartTimerRef.current = setTimeout(() => {
            restartTimerRef.current = null;
            if (recognitionRef.current && !isRecognitionRunningRef.current) {
              try {
                recognitionRef.current.start();
              } catch (err: any) {
                if (err.name === 'DOMException' && (err.message.includes('already started') || err.message.includes('starting'))) {
                  isRecognitionRunningRef.current = true;
                } else {
                  console.error('Error restarting recognition:', err);
                }
              }
            }
          }, restartDelay);
        }
      };

      recognitionRef.current.onerror = (event: any) => {
        lastErrorRef.current = event.error;
        
        if (event.error === 'aborted') {
          return;
        }
        
        if (event.error === 'not-allowed') {
          console.error('Speech recognition error:', event.error);
          setError('Microphone access denied. Please click the lock icon in your browser address bar and allow microphone access for this site.');
          setIsRecording(false);
          isRecognitionRunningRef.current = false;
          // Stop any pending restarts
          if (restartTimerRef.current) {
            clearTimeout(restartTimerRef.current);
            restartTimerRef.current = null;
          }
        } else if (event.error === 'no-speech') {
          // Ignore no-speech errors in continuous mode, engine will restart via onend
          // We don't log this to console to avoid cluttering
        } else {
          console.error('Speech recognition error:', event.error);
          setError(`Speech recognition error: ${event.error}`);
          setIsRecording(false);
          isRecognitionRunningRef.current = false;
        }
      };

      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error('Initial recognition start failed:', err);
      }
    } else {
      setError('Speech recognition is not supported in this browser.');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.onstart = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onresult = null;
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      if (restartTimerRef.current) {
        clearTimeout(restartTimerRef.current);
      }
    };
  }, []);

  const processInput = async (text: string, duration: number = 0) => {
    if (!text.trim()) return;
    
    // Log activity
    const newLog: ActivityLog = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      duration: duration || 10, // Default 10s for text input
      type: mode
    };
    setActivityLogs(prev => [...prev, newLog]);

    if (!isOnline) {
      if (mode === 'pronunciation' && currentDrill) {
        const analysis = analyzePronunciationOffline(currentDrill.sentence, text);
        setPronunciationAnalysis(analysis);
        setPronunciationHistory(prev => [{
          id: crypto.randomUUID(),
          timestamp: Date.now(),
          sentence: currentDrill.sentence,
          analysis
        }, ...prev]);
        return;
      }
      
      if (mode === 'chat' || mode === 'coach' || mode === 'exercise') {
        const userMsg: ChatMessage = { role: 'user', text };
        const aiMsg: ChatMessage = { role: 'ai', text: "I'm currently offline. I can't provide AI feedback right now, but I've logged your practice session! Connect to the internet to chat with me again." };
        setChatHistory(prev => [...prev, userMsg, aiMsg]);
        return;
      }
    }

    setIsLoading(true);
    setError(null);
    try {
      if (mode === 'pronunciation' && currentDrill) {
        setIsAnalyzingPronunciation(true);
        const analysis = await analyzePronunciation(currentDrill.sentence, text);
        const analysisWithTranscript = { ...analysis, userTranscript: text };
        setPronunciationAnalysis(analysisWithTranscript);
        
        // Save to history
        const historyItem: PronunciationHistoryItem = {
          id: Math.random().toString(36).substr(2, 9),
          timestamp: Date.now(),
          sentence: currentDrill.sentence,
          analysis: analysisWithTranscript
        };
        setPronunciationHistory(prev => [historyItem, ...prev]);
        
        setIsAnalyzingPronunciation(false);
        return;
      }
      if (mode === 'coach') {
        const result = await getCorrection(text, userLevel);
        setFeedback({
          original: result.original || text,
          corrected: result.corrected || 'N/A',
          improved: result.improved || 'N/A',
          business: result.business || 'N/A',
          pronunciation: result.pronunciation || 'N/A',
          vocabulary: result.vocabulary || [],
          explanation: result.feedback || 'N/A'
        });
        // Combine text for a single TTS call to reduce latency
        const combinedText = `Corrected: ${result.corrected}. Feedback: ${result.feedback}`;
        speakText(combinedText);
      } else if (mode === 'chat' || mode === 'exercise') {
        const userMsg: ChatMessage = { role: 'user', text };
        const newHistory = [...chatHistory, userMsg];
        setChatHistory(newHistory);
        
        const scenario = mode === 'exercise' ? currentExercise?.scenario : (mode === 'chat' ? selectedScenario : undefined);
        const objectives = mode === 'exercise' ? currentExercise?.objectives : undefined;
        const aiResponse = await getConversationResponse(text, userLevel, newHistory, scenario, objectives);
        const aiMsg: ChatMessage = { role: 'ai', text: aiResponse };
        const updatedHistory = [...newHistory, aiMsg];
        setChatHistory(updatedHistory);
        
        // Update session in history
        if (currentSessionId) {
          setSessions(prev => prev.map(s => 
            s.id === currentSessionId 
              ? { ...s, history: updatedHistory, timestamp: Date.now(), title: s.title === 'New Conversation' ? text.slice(0, 30) + '...' : s.title }
              : s
          ));
        }

        speakText(aiResponse);
      }
    } catch (err) {
      console.error('AI Processing error:', err);
      setError('Failed to get response from AI. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartPractice = async (word: string) => {
    setIsPracticeLoading(true);
    setPracticeFeedback(null);
    setPracticeInput('');
    try {
      const challenge = await getVocabularyPractice(word, userLevel);
      setPracticeChallenge({ ...challenge, word });
      
      // Log vocabulary practice start as a session
      const newLog: ActivityLog = {
        id: crypto.randomUUID(),
        timestamp: Date.now(),
        duration: 30, // Estimated 30s
        type: 'vocabulary'
      };
      setActivityLogs(prev => [...prev, newLog]);
    } catch (err) {
      console.error('Failed to get practice challenge:', err);
      setError('Failed to generate challenge. Please try again.');
    } finally {
      setIsPracticeLoading(false);
    }
  };

  const handleCheckPractice = () => {
    if (!practiceChallenge) return;
    const isCorrect = practiceInput.toLowerCase().trim() === practiceChallenge.answer.toLowerCase().trim();
    setPracticeFeedback(isCorrect ? 'correct' : 'incorrect');
    if (isCorrect) {
      speakText(`Correct! The word is ${practiceChallenge.answer}.`);
    } else {
      speakText(`Not quite. The correct answer is ${practiceChallenge.answer}.`);
    }
  };

  const speakText = (text: string): Promise<void> => {
    return new Promise(async (resolve, reject) => {
      try {
        if (isOnline) {
          const base64Audio = await getSpeechResponse(text);
          if (base64Audio) {
            const binary = atob(base64Audio);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) {
              bytes[i] = binary.charCodeAt(i);
            }
            
            const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
            const audioBuffer = audioContext.createBuffer(1, bytes.length / 2, 24000);
            const channelData = audioBuffer.getChannelData(0);
            
            const view = new Int16Array(bytes.buffer);
            for (let i = 0; i < view.length; i++) {
              channelData[i] = view[i] / 32768;
            }
            
            const source = audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.playbackRate.value = playbackSpeed;
            source.connect(audioContext.destination);
            source.onended = () => {
              audioContext.close();
              resolve();
            };
            source.start();
            return;
          }
        }
        
        // Browser fallback (Offline or AI failure)
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = playbackSpeed;
        utterance.onend = () => resolve();
        utterance.onerror = (e) => {
          console.error('SpeechSynthesis error:', e);
          resolve(); // Resolve anyway to not block
        };
        window.speechSynthesis.speak(utterance);
      } catch (err) {
        console.error('Error playing audio:', err);
        // Last resort fallback
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = playbackSpeed;
        utterance.onend = () => resolve();
        window.speechSynthesis.speak(utterance);
      }
    });
  };

  const reset = () => {
    setFeedback(null);
    setTranscript('');
    setChatHistory([]);
    setError(null);
    setPracticeChallenge(null);
    setPracticeFeedback(null);
    setCurrentSessionId(null);
    setCurrentExercise(null);
    setCurrentDrill(null);
    setPronunciationAnalysis(null);
  };

  const createNewSession = () => {
    const initialMsg: ChatMessage = { role: 'ai', text: `Hello! I'm your ${userLevel} level English partner. How are you feeling today?` };
    const newSession: ChatSession = {
      id: crypto.randomUUID(),
      title: 'New Conversation',
      timestamp: Date.now(),
      history: [initialMsg],
      level: userLevel
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    setChatHistory([initialMsg]);
    setMode('chat');
    setShowHistory(false);
    setCurrentExercise(null);
  };

  const fetchExercises = async () => {
    setIsLoadingExercises(true);
    try {
      const levelToFetch = exerciseDifficulty === 'all' ? userLevel : exerciseDifficulty;
      const suggestions = await getExerciseSuggestions(levelToFetch);
      setExerciseSuggestions(suggestions);
      
      // Set the first one as daily challenge if not already set
      if (suggestions.length > 0 && !dailyChallenge) {
        setDailyChallenge(suggestions[0]);
      }
    } catch (error) {
      console.error('Error fetching exercises:', error);
    } finally {
      setIsLoadingExercises(false);
    }
  };

  useEffect(() => {
    if (mode === 'exercise') {
      fetchExercises();
    }
  }, [mode, userLevel, exerciseDifficulty]);

  const startExerciseSession = async (exercise: Exercise) => {
    setCurrentExercise(exercise);
    const initialGreeting = `Hi! Let's start our ${exercise.type} exercise: "${exercise.title}". ${exercise.description}. I'll start now.`;
    const sessionId = crypto.randomUUID();
    const newSession: ChatSession = {
      id: sessionId,
      title: exercise.title,
      timestamp: Date.now(),
      history: [{ role: 'ai', text: initialGreeting }],
      level: userLevel
    };
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(sessionId);
    setChatHistory(newSession.history);
    
    setIsLoading(true);
    try {
      const aiStart = await getConversationResponse("Let's begin.", userLevel, [], exercise.scenario, exercise.objectives);
      const updatedHistory = [...newSession.history, { role: 'ai' as const, text: aiStart }];
      setChatHistory(updatedHistory);
      setSessions(prev => prev.map(s => s.id === sessionId ? { ...s, history: updatedHistory } : s));
      speakText(aiStart);
    } catch (error) {
      console.error('Error starting exercise:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadSession = (session: ChatSession) => {
    setCurrentSessionId(session.id);
    setChatHistory(session.history);
    setUserLevel(session.level);
    setMode('chat');
    setShowHistory(false);
  };

  const deleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSessions(prev => prev.filter(s => s.id !== id));
    if (currentSessionId === id) {
      reset();
    }
  };

  const handlePracticeWord = async (word: string) => {
    setIsPracticeLoading(true);
    setPracticeFeedback(null);
    setPracticeInput('');
    try {
      const result = await getVocabularyPractice(word, userLevel);
      setPracticeChallenge({ word, ...result });
    } catch (err) {
      console.error('Practice error:', err);
      setError('Failed to generate practice challenge.');
    } finally {
      setIsPracticeLoading(false);
    }
  };

  const checkPracticeAnswer = () => {
    if (!practiceChallenge) return;
    if (practiceInput.toLowerCase().trim() === practiceChallenge.answer.toLowerCase().trim()) {
      setPracticeFeedback('correct');
      speakText(`Correct! The sentence is: ${practiceChallenge.sentence}`);
    } else {
      setPracticeFeedback('incorrect');
    }
  };

  const requestPermission = async () => {
    try {
      setError(null);
      await navigator.mediaDevices.getUserMedia({ audio: true });
      // If successful, we can try starting recognition again
      setIsRecording(true);
    } catch (err) {
      console.error('Permission request failed:', err);
      setError('Microphone access is still denied. Please check your browser settings.');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-brand-bg text-white font-sans selection:bg-brand-pink/30">
      {/* Top Header */}
      <header className="sticky top-0 z-40 w-full bg-brand-bg/80 backdrop-blur-xl border-b border-white/5 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-brand-pink to-brand-purple rounded-xl flex items-center justify-center shadow-lg shadow-brand-purple/20">
            <Sparkles className="text-white w-5 h-5" />
          </div>
          <h1 className="text-xl font-black tracking-tighter bg-gradient-to-r from-white to-white/60 bg-clip-text text-transparent">
            Speakit
          </h1>
        </div>
        <div className="flex items-center gap-2">
          {!isOnline && (
            <div className="flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl text-amber-500 text-[10px] font-black uppercase tracking-widest animate-pulse">
              <AlertCircle className="w-3 h-3" />
              Offline Mode
            </div>
          )}
          {mode === 'pronunciation' && (
            <div className="flex items-center bg-white/5 px-3 py-1.5 rounded-xl border border-white/5 gap-2 mr-2">
              <Volume2 className="w-3.5 h-3.5 text-white/40" />
              <select 
                value={playbackSpeed}
                onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                className="bg-transparent text-[10px] font-black text-white/60 focus:outline-none cursor-pointer hover:text-white transition-colors"
              >
                <option value="0.5" className="bg-brand-card">0.5x</option>
                <option value="0.75" className="bg-brand-card">0.75x</option>
                <option value="1.0" className="bg-brand-card">1.0x</option>
                <option value="1.25" className="bg-brand-card">1.25x</option>
                <option value="1.5" className="bg-brand-card">1.5x</option>
                <option value="2.0" className="bg-brand-card">2.0x</option>
              </select>
            </div>
          )}
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className={cn(
              "p-2 rounded-xl transition-all",
              showHistory ? "bg-brand-pink/20 text-brand-pink" : "text-white/40 hover:text-white"
            )}
          >
            <History className="w-5 h-5" />
          </button>
          <button 
            onClick={() => setShowSettings(true)}
            className="p-2 rounded-xl text-white/40 hover:text-white transition-all"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* History Sidebar */}
      <AnimatePresence>
        {showHistory && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHistory(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            />
            <motion.aside 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-80 bg-brand-bg border-l border-white/10 z-50 p-6 flex flex-col gap-6 shadow-2xl backdrop-blur-3xl"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold flex items-center gap-2">
                  <History className="w-5 h-5 text-brand-pink" />
                  History
                </h3>
                <button 
                  onClick={() => setShowHistory(false)}
                  className="p-1 hover:bg-white/5 rounded-lg text-white/40 hover:text-white"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <button 
                onClick={createNewSession}
                className="w-full py-3 bg-gradient-to-r from-brand-pink to-brand-purple hover:opacity-90 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-purple/20"
              >
                <Sparkles className="w-4 h-4" />
                New Conversation
              </button>

              <div className="flex-1 overflow-y-auto space-y-3 pr-2 scrollbar-hide">
                {sessions.length === 0 ? (
                  <div className="text-center py-12 opacity-20 space-y-2">
                    <MessageSquare className="w-8 h-8 mx-auto" />
                    <p className="text-xs uppercase tracking-widest font-bold">No history yet</p>
                  </div>
                ) : (
                  sessions.map(session => (
                    <div 
                      key={session.id}
                      onClick={() => loadSession(session)}
                      className={cn(
                        "p-4 rounded-2xl border transition-all cursor-pointer group relative",
                        currentSessionId === session.id 
                          ? "bg-brand-pink/10 border-brand-pink/50" 
                          : "bg-brand-card/50 border-white/5 hover:border-white/20"
                      )}
                    >
                      <h4 className="text-sm font-bold truncate pr-6">{session.title}</h4>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-[10px] text-white/40">
                          {new Date(session.timestamp).toLocaleDateString()}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-brand-pink/60">
                          {session.level}
                        </span>
                      </div>
                      <button 
                        onClick={(e) => deleteSession(e, session.id)}
                        className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 p-1 hover:bg-brand-pink/20 rounded-md text-brand-pink transition-all"
                      >
                        <RotateCcw className="w-3 h-3" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-lg bg-brand-card border border-white/10 rounded-[40px] p-10 shadow-2xl overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-pink via-brand-purple to-brand-cyan" />
              
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-pink/10 rounded-2xl flex items-center justify-center text-brand-pink">
                    <Settings className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-black tracking-tight">Settings</h2>
                </div>
                <button 
                  onClick={() => setShowSettings(false)}
                  className="p-2 hover:bg-white/5 rounded-xl text-white/40 hover:text-white transition-colors"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-8">
                {/* User Profile Section */}
                <div className="space-y-4">
                  <label className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-black">Learning Profile</label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-black/20 border border-white/5 p-6 rounded-3xl space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white/60">Proficiency Level</span>
                        <div className="flex gap-2">
                          {(['beginner', 'intermediate', 'advanced'] as const).map((lvl) => (
                            <button
                              key={lvl}
                              onClick={() => setUserLevel(lvl)}
                              className={cn(
                                "px-3 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all",
                                userLevel === lvl ? "bg-brand-pink text-white shadow-lg shadow-brand-pink/20" : "bg-white/5 text-white/40 hover:text-white/60"
                              )}
                            >
                              {lvl}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Preferences Section */}
                <div className="space-y-4">
                  <label className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-black">Preferences</label>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-black/20 border border-white/5 rounded-2xl">
                      <div className="flex items-center gap-3">
                        <Volume2 className="w-5 h-5 text-brand-cyan" />
                        <span className="text-sm font-bold text-white/80">Default Playback Speed</span>
                      </div>
                      <select 
                        value={playbackSpeed}
                        onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                        className="bg-brand-card border border-white/10 rounded-xl px-3 py-1.5 text-xs font-bold text-white focus:outline-none"
                      >
                        <option value="0.5">0.5x</option>
                        <option value="0.75">0.75x</option>
                        <option value="1.0">1.0x</option>
                        <option value="1.25">1.25x</option>
                        <option value="1.5">1.5x</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Goals Section */}
                <div className="space-y-4">
                  <label className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-black">Learning Goals</label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Weekly Goal */}
                    <div className="bg-black/20 border border-white/5 p-6 rounded-3xl space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white/60">Weekly</span>
                        <div className="flex gap-1">
                          {(['minutes', 'sessions'] as const).map((type) => (
                            <button
                              key={type}
                              onClick={() => setGoals(prev => ({ ...prev, weekly: { ...prev.weekly!, type } }))}
                              className={cn(
                                "px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all",
                                goals.weekly?.type === type ? "bg-brand-pink text-white" : "bg-white/5 text-white/40"
                              )}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <input 
                          type="number"
                          value={goals.weekly?.target || 0}
                          onChange={(e) => setGoals(prev => ({ ...prev, weekly: { ...prev.weekly!, target: parseInt(e.target.value) || 0 } }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-lg font-black text-white focus:outline-none focus:border-brand-pink/50 transition-all"
                        />
                        <span className="text-xs font-bold text-white/20 uppercase tracking-widest">{goals.weekly?.type === 'minutes' ? 'min' : 'sesh'}</span>
                      </div>
                    </div>

                    {/* Monthly Goal */}
                    <div className="bg-black/20 border border-white/5 p-6 rounded-3xl space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white/60">Monthly</span>
                        <div className="flex gap-1">
                          {(['minutes', 'sessions'] as const).map((type) => (
                            <button
                              key={type}
                              onClick={() => setGoals(prev => ({ ...prev, monthly: { ...prev.monthly!, type } }))}
                              className={cn(
                                "px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all",
                                goals.monthly?.type === type ? "bg-brand-pink text-white" : "bg-white/5 text-white/40"
                              )}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <input 
                          type="number"
                          value={goals.monthly?.target || 0}
                          onChange={(e) => setGoals(prev => ({ ...prev, monthly: { ...prev.monthly!, target: parseInt(e.target.value) || 0 } }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-lg font-black text-white focus:outline-none focus:border-brand-pink/50 transition-all"
                        />
                        <span className="text-xs font-bold text-white/20 uppercase tracking-widest">{goals.monthly?.type === 'minutes' ? 'min' : 'sesh'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Danger Zone */}
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <label className="text-[10px] uppercase tracking-[0.2em] text-red-500/60 font-black">Danger Zone</label>
                  <button 
                    onClick={() => {
                      if (window.confirm('Are you sure you want to clear all conversation history? This cannot be undone.')) {
                        setSessions([]);
                        setChatHistory([]);
                        setCurrentSessionId(null);
                        localStorage.removeItem('speakflow_sessions');
                        setShowSettings(false);
                      }
                    }}
                    className="w-full p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-between group hover:bg-red-500/20 transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <RotateCcw className="w-5 h-5 text-red-500" />
                      <span className="text-sm font-bold text-red-500">Clear All History</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-red-500/40 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              <div className="mt-10 pt-6 border-t border-white/5 flex justify-center">
                <p className="text-[10px] font-black text-white/20 uppercase tracking-[0.3em]">Speakit v1.0.0 • AI Language Coach</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Goals Progress Modal */}
      <AnimatePresence>
        {showGoalsProgress && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowGoalsProgress(false)}
              className="absolute inset-0 bg-black/80 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-2xl bg-brand-card border border-white/10 rounded-[40px] p-10 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-pink via-brand-purple to-brand-cyan" />
              
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-pink/10 rounded-2xl flex items-center justify-center text-brand-pink">
                    <Activity className="w-6 h-6" />
                  </div>
                  <h2 className="text-2xl font-black tracking-tight">Learning Progress</h2>
                </div>
                <button 
                  onClick={() => setShowGoalsProgress(false)}
                  className="p-2 hover:bg-white/5 rounded-xl text-white/40 hover:text-white transition-colors"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-8 pr-2 scrollbar-hide">
                {/* Goals Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(['weekly', 'monthly'] as const).map((period) => {
                    const progress = getProgress(period);
                    if (!progress) return null;
                    const percentage = Math.min(100, (progress.current / progress.target) * 100);
                    
                    return (
                      <div key={period} className="bg-black/20 border border-white/5 p-8 rounded-[32px] space-y-6 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 p-6 opacity-10 group-hover:opacity-20 transition-opacity">
                          <Target className="w-12 h-12" />
                        </div>
                        
                        <div className="space-y-1">
                          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30">{period} goal</p>
                          <h4 className="text-2xl font-black capitalize">{progress.unit === 'min' ? 'Practice Time' : 'Sessions'}</h4>
                        </div>

                        <div className="space-y-4">
                          <div className="flex items-end justify-between">
                            <div className="flex items-baseline gap-1">
                              <span className="text-4xl font-black text-brand-pink">{progress.current}</span>
                              <span className="text-sm font-bold text-white/40">/ {progress.target} {progress.unit}</span>
                            </div>
                            <span className="text-xs font-black text-brand-pink/60">{Math.round(percentage)}%</span>
                          </div>
                          
                          <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${percentage}%` }}
                              transition={{ duration: 1, ease: "easeOut" }}
                              className="h-full bg-gradient-to-r from-brand-pink to-brand-purple rounded-full shadow-[0_0_15px_rgba(236,72,153,0.3)]"
                            />
                          </div>
                        </div>

                        <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">
                          {progress.current >= progress.target ? "Goal Achieved! 🏆" : `${progress.target - progress.current} ${progress.unit} to go`}
                        </p>
                      </div>
                    );
                  })}
                </div>

                {/* Activity Stats */}
                <div className="space-y-4">
                  <label className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-black">Recent Activity</label>
                  <div className="bg-black/20 border border-white/5 rounded-[32px] overflow-hidden">
                    {activityLogs.length === 0 ? (
                      <div className="p-12 text-center opacity-20">
                        <Activity className="w-8 h-8 mx-auto mb-2" />
                        <p className="text-xs font-bold uppercase tracking-widest">No activity logged yet</p>
                      </div>
                    ) : (
                      <div className="divide-y divide-white/5">
                        {activityLogs.slice().reverse().slice(0, 5).map((log) => (
                          <div key={log.id} className="p-6 flex items-center justify-between hover:bg-white/5 transition-colors">
                            <div className="flex items-center gap-4">
                              <div className={cn(
                                "w-10 h-10 rounded-xl flex items-center justify-center",
                                log.type === 'pronunciation' ? "bg-brand-pink/10 text-brand-pink" :
                                log.type === 'vocabulary' ? "bg-brand-cyan/10 text-brand-cyan" :
                                "bg-brand-purple/10 text-brand-purple"
                              )}>
                                {log.type === 'pronunciation' ? <Volume2 className="w-5 h-5" /> :
                                 log.type === 'vocabulary' ? <BookOpen className="w-5 h-5" /> :
                                 <MessageSquare className="w-5 h-5" />}
                              </div>
                              <div>
                                <p className="text-sm font-bold capitalize">{log.type} Practice</p>
                                <p className="text-[10px] text-white/40">{new Date(log.timestamp).toLocaleString()}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-black text-white/80">{Math.round(log.duration / 60)}m {log.duration % 60}s</p>
                              <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Duration</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-white/5 flex justify-center">
                <button 
                  onClick={() => { setShowGoalsProgress(false); setShowSettings(true); }}
                  className="text-[10px] font-black text-brand-pink uppercase tracking-[0.2em] hover:text-brand-purple transition-colors"
                >
                  Adjust Goals in Settings
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-x-hidden pb-24">
        {/* Background Gradients */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-brand-purple/20 blur-[120px] rounded-full" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-brand-cyan/10 blur-[120px] rounded-full" />
        </div>

        <div className="max-w-5xl mx-auto w-full px-4 py-6">
          <AnimatePresence mode="wait">
          {mode === 'coach' ? (
            <motion.div 
              key="coach"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              {/* Hero Section */}
              <div className="text-center space-y-6 py-8">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="inline-block px-4 py-1.5 bg-brand-pink/10 border border-brand-pink/20 rounded-full text-[10px] font-black uppercase tracking-[0.3em] text-brand-pink mb-4"
                >
                  AI Language Coach
                </motion.div>
                <h2 className="text-5xl md:text-7xl font-black tracking-tighter leading-[0.9] max-w-3xl mx-auto">
                  Master Your <span className="text-brand-pink">English</span> Fluency
                </h2>
                <p className="text-white/40 text-lg max-w-xl mx-auto font-medium leading-relaxed">
                  Speak naturally and get real-time feedback on your grammar, vocabulary, and pronunciation.
                </p>
              </div>

              <div className="flex flex-col items-center gap-16">
                <div className="relative group">
                  {/* Pulse Effect */}
                  <AnimatePresence>
                    {isRecording && (
                      <>
                        <motion.div 
                          initial={{ scale: 1, opacity: 0 }}
                          animate={{ scale: [1, 2, 1], opacity: [0.4, 0, 0.4] }}
                          exit={{ scale: 1, opacity: 0 }}
                          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                          className="absolute inset-0 bg-brand-pink/30 rounded-full blur-3xl"
                        />
                        <motion.div 
                          initial={{ scale: 1, opacity: 0 }}
                          animate={{ scale: [1, 1.5, 1], opacity: [0.6, 0, 0.6] }}
                          exit={{ scale: 1, opacity: 0 }}
                          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                          className="absolute inset-0 bg-brand-purple/20 rounded-full blur-2xl"
                        />
                      </>
                    )}
                  </AnimatePresence>
                  
                  <button
                    onClick={() => setIsRecording(!isRecording)}
                    className={cn(
                      "relative w-48 h-48 rounded-full flex items-center justify-center transition-all duration-700",
                      "bg-brand-bg border-4 border-white/5 shadow-[0_0_80px_rgba(0,0,0,0.5)]",
                      "hover:border-brand-pink/30 hover:scale-105 active:scale-95",
                      isRecording && "border-brand-pink shadow-[0_0_100px_rgba(255,45,85,0.4)] scale-110"
                    )}
                  >
                    <div className={cn(
                      "absolute inset-4 rounded-full transition-all duration-700",
                      isRecording ? "bg-brand-pink" : "bg-white/5"
                    )} />
                    <div className="relative z-10">
                      {isRecording ? (
                        <motion.div
                          animate={{ scale: [1, 1.1, 1] }}
                          transition={{ duration: 1, repeat: Infinity }}
                        >
                          <MicOff className="w-16 h-16 text-white" />
                        </motion.div>
                      ) : (
                        <Mic className="w-16 h-16 text-white/40 group-hover:text-white transition-colors" />
                      )}
                    </div>
                  </button>
                </div>

                <div className="w-full max-w-2xl space-y-10">
                  <div className="h-16 flex flex-col items-center justify-center gap-4">
                    {isRecording ? (
                      <div className="flex items-center gap-1.5 h-12">
                        {audioData.slice(0, 32).map((value, i) => (
                          <motion.div 
                            key={i}
                            animate={{ 
                              height: Math.max(4, value * 48),
                              opacity: 0.3 + (value * 0.7)
                            }}
                            transition={{ type: 'spring', stiffness: 400, damping: 25 }}
                            className={cn(
                              "w-1.5 rounded-full",
                              i % 2 === 0 ? "bg-brand-pink" : "bg-brand-purple"
                            )}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-2">
                        <p className="text-white/20 text-[10px] font-black uppercase tracking-[0.4em] animate-pulse">Tap mic to speak or type below</p>
                        <div className="w-12 h-0.5 bg-white/5 rounded-full" />
                      </div>
                    )}
                    
                    {isRecording && transcript && (
                      <motion.p 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-sm text-brand-pink font-bold italic tracking-tight"
                      >
                        "{transcript}..."
                      </motion.p>
                    )}
                  </div>

                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (manualInput.trim()) {
                        processInput(manualInput);
                        setManualInput('');
                      }
                    }}
                    className="relative max-w-lg mx-auto w-full"
                  >
                    <input 
                      type="text"
                      value={manualInput}
                      onChange={(e) => setManualInput(e.target.value)}
                      placeholder="Type your sentence to analyze..."
                      className="w-full bg-white/5 border border-white/10 rounded-[2rem] px-8 py-5 pr-16 text-base focus:outline-none focus:border-brand-pink/50 focus:bg-white/10 transition-all backdrop-blur-3xl"
                    />
                    <button 
                      type="submit"
                      disabled={!manualInput.trim()}
                      className="absolute right-3 top-1/2 -translate-y-1/2 p-3 text-brand-pink hover:bg-brand-pink/10 rounded-2xl disabled:opacity-0 transition-all"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </form>
                </div>
              </div>

              {/* Transcript / Feedback Area */}
              <div className="min-h-[200px]">
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center gap-4 py-12">
                    <div className="w-12 h-12 border-4 border-brand-pink/20 border-t-brand-pink rounded-full animate-spin" />
                    <p className="text-white/40 animate-pulse">Analyzing your speech...</p>
                  </div>
                ) : feedback ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  >
                    <div className="bg-brand-card/50 border border-white/5 rounded-[2.5rem] p-10 space-y-8 backdrop-blur-2xl shadow-2xl">
                      <div>
                        <label className="text-[10px] uppercase tracking-[0.2em] text-white/30 font-black mb-3 block">Your Sentence</label>
                        <p className="text-2xl font-semibold text-white/90 italic leading-tight">"{feedback.original}"</p>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                        <div>
                          <label className="text-[10px] uppercase tracking-[0.2em] text-brand-pink/60 font-black mb-3 block">Corrected</label>
                          <p className="text-xl font-bold text-brand-pink">{feedback.corrected}</p>
                          <p className="text-xs text-white/30 mt-2 font-mono tracking-wider">{feedback.pronunciation}</p>
                        </div>
                        <div>
                          <label className="text-[10px] uppercase tracking-[0.2em] text-brand-cyan/60 font-black mb-3 block">Improved</label>
                          <p className="text-xl font-bold text-brand-cyan">{feedback.improved}</p>
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] uppercase tracking-[0.2em] text-brand-purple/60 font-black mb-3 block">Business Version</label>
                        <p className="text-xl font-bold text-brand-purple">{feedback.business}</p>
                      </div>
                      {feedback.vocabulary.length > 0 && (
                        <div>
                          <label className="text-[10px] uppercase tracking-[0.2em] text-amber-500/60 font-black mb-3 block">Key Vocabulary</label>
                          <div className="flex flex-wrap gap-3 mt-3">
                            {feedback.vocabulary.map((word, i) => (
                              <button 
                                key={i} 
                                onClick={() => handlePracticeWord(word)}
                                className="px-3 py-1.5 bg-amber-500/5 border border-amber-500/10 rounded-xl text-xs text-amber-400 font-bold hover:bg-amber-500/10 transition-all flex items-center gap-2"
                              >
                                {word}
                                <Sparkles className="w-3 h-3" />
                              </button>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="bg-gradient-to-br from-brand-purple/10 to-brand-pink/5 border border-white/5 rounded-[2.5rem] p-10 space-y-6 backdrop-blur-2xl shadow-2xl">
                      <div className="flex items-center gap-3 text-brand-pink">
                        <Sparkles className="w-6 h-6" />
                        <h3 className="font-black uppercase tracking-[0.2em] text-xs">Coach Feedback</h3>
                      </div>
                      <div className="text-white/60 leading-relaxed prose prose-invert prose-sm font-medium">
                        <ReactMarkdown>{feedback.explanation}</ReactMarkdown>
                      </div>
                      <div className="flex gap-4 mt-4">
                        <button 
                          onClick={reset}
                          className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm font-medium"
                        >
                          <RotateCcw className="w-4 h-4" /> Try another
                        </button>
                        <button 
                          onClick={() => {
                            setMode('chat');
                            setChatHistory([
                              { role: 'user', text: feedback.original },
                              { role: 'ai', text: `That's a good sentence! Let's talk more about it. Your corrected version was: "${feedback.corrected}". How else can I help you with this?` }
                            ]);
                          }}
                          className="flex items-center gap-2 text-red-500/60 hover:text-red-500 transition-colors text-sm font-medium"
                        >
                          <MessageSquare className="w-4 h-4" /> Discuss in Chat
                        </button>
                      </div>

                      {/* Vocabulary Practice Section */}
                      <AnimatePresence>
                        {(isPracticeLoading || practiceChallenge) && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-6 pt-6 border-t border-white/5 space-y-4"
                          >
                            <div className="flex items-center justify-between">
                              <h4 className="text-xs font-bold uppercase tracking-widest text-amber-500/60">Vocabulary Practice</h4>
                              <button onClick={() => setPracticeChallenge(null)} className="text-white/20 hover:text-white">
                                <RotateCcw className="w-3 h-3" />
                              </button>
                            </div>

                            {isPracticeLoading ? (
                              <div className="flex items-center gap-2 text-white/40 text-xs animate-pulse">
                                <Sparkles className="w-3 h-3 animate-spin text-brand-pink" />
                                Generating challenge...
                              </div>
                            ) : practiceChallenge && (
                              <div className="space-y-4">
                                <p className="text-sm text-white/80 font-medium leading-relaxed">
                                  {practiceChallenge.challenge}
                                </p>
                                <div className="flex gap-2">
                                  <input 
                                    type="text"
                                    value={practiceInput}
                                    onChange={(e) => setPracticeInput(e.target.value)}
                                    placeholder="Type the missing word..."
                                    className={cn(
                                      "flex-1 bg-black/40 border rounded-xl px-4 py-2 text-sm focus:outline-none transition-colors",
                                      practiceFeedback === 'correct' ? "border-emerald-500/50 text-emerald-400" : 
                                      practiceFeedback === 'incorrect' ? "border-brand-pink/50 text-brand-pink" : "border-white/10"
                                    )}
                                    onKeyDown={(e) => e.key === 'Enter' && checkPracticeAnswer()}
                                  />
                                  <button 
                                    onClick={checkPracticeAnswer}
                                    className="bg-amber-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-amber-500 transition-colors"
                                  >
                                    Check
                                  </button>
                                </div>
                                {practiceFeedback === 'correct' && (
                                  <motion.p 
                                    initial={{ opacity: 0 }} 
                                    animate={{ opacity: 1 }}
                                    className="text-xs text-emerald-400 font-medium"
                                  >
                                    ✨ Well done! "{practiceChallenge.sentence}"
                                  </motion.p>
                                )}
                                {practiceFeedback === 'incorrect' && (
                                  <p className="text-xs text-brand-pink font-medium">
                                    Try again! Hint: It starts with "{practiceChallenge.word[0]}"
                                  </p>
                                )}
                              </div>
                            )}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </motion.div>
                ) : transcript && (
                  <div className="text-center py-12">
                    <p className="text-2xl text-white/60 font-light italic">"{transcript}"</p>
                  </div>
                )}
              </div>
            </motion.div>
          ) : mode === 'exercise' ? (
            <motion.div 
              key="exercise"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex flex-col max-w-4xl mx-auto w-full"
            >
              {!currentExercise ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 space-y-8">
                  <div className="text-center space-y-2">
                    <h2 className="text-3xl font-bold text-white tracking-tight">Structured Exercises</h2>
                    <p className="text-white/40 text-sm">Select a scenario to practice your speaking skills</p>
                  </div>

                  {dailyChallenge && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="w-full bg-gradient-to-br from-brand-pink/10 to-brand-purple/10 border border-brand-pink/20 p-8 rounded-[40px] relative overflow-hidden group"
                    >
                      <div className="absolute top-0 right-0 p-6">
                        <div className="bg-brand-pink text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full shadow-lg shadow-brand-purple/40">
                          Daily Challenge
                        </div>
                      </div>
                      <div className="space-y-4 relative z-10">
                        <div className="space-y-1">
                          <h3 className="text-2xl font-bold text-white">{dailyChallenge.title}</h3>
                          <p className="text-white/60 text-sm leading-relaxed max-w-lg">
                            {dailyChallenge.description}
                          </p>
                        </div>
                        <button 
                          onClick={() => startExerciseSession(dailyChallenge)}
                          className="px-8 py-3 bg-gradient-to-r from-brand-pink to-brand-purple hover:opacity-90 text-white rounded-2xl font-bold text-sm transition-all flex items-center gap-2 shadow-xl shadow-brand-purple/20 group-hover:scale-105"
                        >
                          <Play className="w-4 h-4 fill-current" />
                          Start Challenge
                        </button>
                      </div>
                      <div className="absolute bottom-[-20%] right-[-10%] w-64 h-64 bg-brand-pink/10 blur-[80px] rounded-full group-hover:bg-brand-pink/20 transition-all" />
                    </motion.div>
                  )}

                  <div className="flex bg-brand-card/50 p-1 rounded-2xl border border-white/5 backdrop-blur-xl">
                    {(['all', 'beginner', 'intermediate', 'advanced'] as const).map((lvl) => (
                      <button
                        key={lvl}
                        onClick={() => setExerciseDifficulty(lvl)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all",
                          exerciseDifficulty === lvl ? "bg-brand-pink/20 text-brand-pink" : "text-white/40 hover:text-white/60"
                        )}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>

                  {isLoadingExercises ? (
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-12 h-12 border-4 border-brand-pink border-t-transparent rounded-full animate-spin" />
                      <p className="text-white/20 text-xs font-bold uppercase tracking-widest animate-pulse">Generating custom exercises...</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                      {exerciseSuggestions.map((ex, i) => (
                        <motion.button
                          key={i}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => startExerciseSession(ex)}
                          className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl text-left hover:bg-brand-card transition-all group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                            <ChevronRight className="w-5 h-5 text-brand-pink" />
                          </div>
                          <div className="flex items-center gap-2 mb-3">
                            <span className={cn(
                              "text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-md",
                              ex.type === 'roleplay' ? "bg-brand-cyan/20 text-brand-cyan" : "bg-brand-purple/20 text-brand-purple"
                            )}>
                              {ex.type}
                            </span>
                          </div>
                          <h3 className="text-lg font-bold text-white mb-2">{ex.title}</h3>
                          <p className="text-sm text-white/40 leading-relaxed line-clamp-2 mb-4">{ex.description}</p>
                          {ex.objectives && (
                            <div className="flex flex-wrap gap-2">
                              {ex.objectives.map((obj, idx) => (
                                <span key={idx} className="text-[9px] bg-white/5 border border-white/5 px-2 py-0.5 rounded-full text-white/30">
                                  {obj}
                                </span>
                              ))}
                            </div>
                          )}
                        </motion.button>
                      ))}
                    </div>
                  )}
                  
                  <button 
                    onClick={fetchExercises}
                    className="text-white/20 hover:text-white text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Refresh Suggestions
                  </button>
                </div>
              ) : (
                <div className="flex-1 flex flex-col h-[70vh] bg-brand-card/30 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-xl">
                  {/* Exercise Header */}
                  <div className="p-4 bg-brand-card/50 border-b border-white/10 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button 
                        onClick={() => setCurrentExercise(null)}
                        className="p-2 hover:bg-white/10 rounded-xl text-white/40 hover:text-white transition-colors"
                      >
                        <ChevronRight className="w-5 h-5 rotate-180" />
                      </button>
                      <div>
                        <h3 className="text-sm font-bold text-white">{currentExercise.title}</h3>
                        <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold">{currentExercise.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="hidden md:flex items-center gap-2">
                        {currentExercise.objectives?.map((obj, i) => (
                          <div key={i} className="group relative">
                            <div className="w-2 h-2 rounded-full bg-white/10 border border-white/20" />
                            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-black/80 text-[9px] text-white rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-50">
                              {obj}
                            </div>
                          </div>
                        ))}
                      </div>
                      <button onClick={reset} className="text-white/40 hover:text-white transition-colors">
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Chat Area */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
                    {!isOnline && (
                      <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl flex items-start gap-3"
                      >
                        <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-bold text-amber-500 uppercase tracking-widest mb-1">Offline Mode Active</p>
                          <p className="text-xs text-amber-500/70 leading-relaxed">AI feedback and conversation are limited. Your practice will still be logged locally.</p>
                        </div>
                      </motion.div>
                    )}
                    {chatHistory.map((msg, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={cn(
                          "max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed",
                          msg.role === 'user' 
                            ? "ml-auto bg-brand-pink text-white rounded-tr-none" 
                            : "mr-auto bg-brand-card text-white/90 rounded-tl-none border border-white/5"
                        )}
                      >
                        {msg.text}
                      </motion.div>
                    ))}

                    {chatHistory.length <= 1 && !isLoading && (
                      <motion.div 
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="space-y-4 pt-4"
                      >
                        <div className="flex items-center gap-2 px-2">
                          <Sparkles className="w-3 h-3 text-brand-pink" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Conversation Starters</span>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          {CONVERSATION_STARTERS.map((starter, i) => (
                            <button
                              key={i}
                              onClick={() => {
                                setManualInput(starter.text);
                                processInput(starter.text);
                                setManualInput('');
                              }}
                              className="p-4 bg-brand-card/30 border border-white/5 rounded-2xl text-left hover:bg-brand-card hover:border-brand-pink/20 transition-all group"
                            >
                              <p className="text-[10px] font-bold text-brand-pink/60 uppercase tracking-widest mb-1 group-hover:text-brand-pink transition-colors">{starter.label}</p>
                              <p className="text-xs text-white/40 group-hover:text-white/60 transition-colors line-clamp-1">{starter.text}</p>
                            </button>
                          ))}
                        </div>
                      </motion.div>
                    )}

                    {isLoading && (
                      <div className="mr-auto bg-white/10 p-4 rounded-2xl rounded-tl-none border border-white/5">
                        <div className="flex gap-1">
                          {[0, 1, 2].map(i => (
                            <motion.div 
                              key={i}
                              animate={{ opacity: [0.2, 1, 0.2] }}
                              transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                              className="w-1.5 h-1.5 bg-white/40 rounded-full"
                            />
                          ))}
                        </div>
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Input Area */}
                  <div className="p-4 bg-brand-card/50 border-t border-white/5 backdrop-blur-md">
                    <div className="max-w-2xl mx-auto flex items-center gap-3">
                      <button
                        onClick={() => setIsRecording(!isRecording)}
                        className={cn(
                          "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 shrink-0",
                          isRecording ? "bg-brand-pink animate-pulse shadow-lg shadow-brand-pink/20" : "bg-brand-card/50 hover:bg-brand-card text-white/60 hover:text-white border border-white/5"
                        )}
                      >
                        {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                      </button>
                      
                      <form 
                        onSubmit={(e) => {
                          e.preventDefault();
                          if (manualInput.trim()) {
                            processInput(manualInput);
                            setManualInput('');
                          }
                        }}
                        className="flex-1 relative group"
                      >
                        <input 
                          type="text"
                          value={manualInput}
                          onChange={(e) => setManualInput(e.target.value)}
                          placeholder="Type a message..."
                          className="w-full bg-brand-card/50 border border-white/5 rounded-2xl px-5 py-3 pr-12 text-sm focus:outline-none focus:border-brand-pink/50 focus:bg-brand-card transition-all"
                        />
                        <button 
                          type="submit"
                          disabled={!manualInput.trim()}
                          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-brand-pink hover:text-brand-pink/80 disabled:text-white/10 transition-colors"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </button>
                      </form>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          ) : mode === 'vocabulary' ? (
            <motion.div 
              key="vocabulary"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex flex-col max-w-4xl mx-auto w-full"
            >
              <div className="flex-1 flex flex-col p-6 space-y-8">
                <div className="text-center space-y-2">
                  <h2 className="text-3xl font-bold text-white tracking-tight">Vocabulary Builder</h2>
                  <p className="text-white/40 text-sm">Expand your lexicon with level-appropriate words and idioms</p>
                </div>

                {!isOnline && (
                  <motion.div 
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl flex items-start gap-3"
                  >
                    <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-amber-500 uppercase tracking-widest mb-1">Offline Mode Active</p>
                      <p className="text-xs text-amber-500/70 leading-relaxed">You are viewing cached vocabulary. Connect to the internet to get fresh words and AI challenges.</p>
                    </div>
                  </motion.div>
                )}

                {isLoadingVocabulary ? (
                  <div className="flex-1 flex flex-col items-center justify-center gap-4">
                    <div className="w-12 h-12 border-4 border-brand-pink border-t-transparent rounded-full animate-spin" />
                    <p className="text-white/20 text-xs font-bold uppercase tracking-widest animate-pulse">Curating your word list...</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                    {vocabularyList.map((item, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-4 hover:bg-brand-card transition-all group"
                      >
                        <div className="flex items-center justify-between">
                          <h3 className="text-xl font-bold text-white group-hover:text-brand-pink transition-colors">{item.word}</h3>
                          <button 
                            onClick={() => {
                              setMode('coach');
                              setTranscript(item.word);
                              processInput(item.word);
                            }}
                            className="p-2 bg-brand-pink/10 text-brand-pink rounded-xl hover:bg-brand-pink hover:text-white transition-all"
                            title="Practice this word"
                          >
                            <Sparkles className="w-4 h-4" />
                          </button>
                        </div>
                        <div className="space-y-2">
                          <p className="text-sm text-white/60 leading-relaxed italic">"{item.definition}"</p>
                          <div className="p-3 bg-black/40 rounded-2xl border border-white/5">
                            <p className="text-xs text-white/40 leading-relaxed">
                              <span className="text-brand-pink/60 font-bold mr-2">EX:</span>
                              {item.example}
                            </p>
                          </div>
                        </div>

                        {/* Challenge Section */}
                        <div className="pt-2">
                          {practiceChallenge?.word === item.word ? (
                            <motion.div 
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              className="space-y-3 p-4 bg-brand-pink/5 rounded-2xl border border-brand-pink/10"
                            >
                              <p className="text-xs font-bold text-brand-pink uppercase tracking-widest">Challenge</p>
                              <p className="text-sm text-white leading-relaxed">{practiceChallenge.challenge}</p>
                              <div className="flex gap-2">
                                <input 
                                  type="text"
                                  value={practiceInput}
                                  onChange={(e) => setPracticeInput(e.target.value)}
                                  placeholder="Type the word..."
                                  className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-brand-pink/50 transition-all"
                                  onKeyDown={(e) => e.key === 'Enter' && handleCheckPractice()}
                                />
                                <button 
                                  onClick={handleCheckPractice}
                                  className="px-4 py-2 bg-brand-pink text-white text-xs font-bold rounded-xl hover:bg-brand-pink/80 transition-all"
                                >
                                  Check
                                </button>
                              </div>
                              {practiceFeedback && (
                                <motion.div 
                                  initial={{ opacity: 0, y: -5 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className={cn(
                                    "flex items-center gap-2 text-xs font-bold uppercase tracking-widest",
                                    practiceFeedback === 'correct' ? "text-emerald-400" : "text-brand-pink"
                                  )}
                                >
                                  {practiceFeedback === 'correct' ? (
                                    <><CheckCircle2 className="w-3 h-3" /> Correct!</>
                                  ) : (
                                    <><AlertCircle className="w-3 h-3" /> Try again!</>
                                  )}
                                </motion.div>
                              )}
                            </motion.div>
                          ) : (
                            <button 
                              onClick={() => handleStartPractice(item.word)}
                              disabled={isPracticeLoading}
                              className="w-full py-2 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-white/40 uppercase tracking-widest hover:bg-brand-pink/10 hover:text-brand-pink hover:border-brand-pink/20 transition-all flex items-center justify-center gap-2 group"
                            >
                              {isPracticeLoading ? (
                                <div className="w-3 h-3 border-2 border-brand-pink border-t-transparent rounded-full animate-spin" />
                              ) : (
                                <>
                                  <BookOpen className="w-3 h-3 group-hover:scale-110 transition-transform" />
                                  Take Challenge
                                </>
                              )}
                            </button>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
                
                <button 
                  onClick={fetchVocabulary}
                  className="mx-auto text-white/20 hover:text-white text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors"
                >
                  <RefreshCw className="w-3 h-3" />
                  Get New Words
                </button>
              </div>
            </motion.div>
          ) : mode === 'pronunciation' ? (
            <motion.div 
              key="pronunciation"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="flex-1 flex flex-col max-w-4xl mx-auto w-full"
            >
              {!currentDrill ? (
                <div className="flex-1 flex flex-col p-6 space-y-8">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h2 className="text-3xl font-bold text-white tracking-tight">Pronunciation Drills</h2>
                      <p className="text-white/40 text-sm">Master difficult sounds and natural rhythm</p>
                    </div>

                    {!isOnline && (
                      <motion.div 
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="bg-amber-500/10 border border-amber-500/20 p-4 rounded-2xl flex items-start gap-3"
                      >
                        <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                        <div>
                          <p className="text-xs font-bold text-amber-500 uppercase tracking-widest mb-1">Offline Mode Active</p>
                          <p className="text-xs text-amber-500/70 leading-relaxed">You are using cached drills. Analysis is performed locally and may be less detailed than AI analysis.</p>
                        </div>
                      </motion.div>
                    )}
                    <div className="flex items-center gap-2">
                      <button 
                        onClick={() => {
                          setShowPronunciationProgress(!showPronunciationProgress);
                          setShowPronunciationHistory(false);
                        }}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-2xl transition-all border",
                          showPronunciationProgress 
                            ? "bg-brand-pink/10 border-brand-pink/50 text-brand-pink" 
                            : "bg-brand-card/50 border-white/5 text-white/40 hover:text-white"
                        )}
                      >
                        <TrendingUp className="w-4 h-4" />
                        <span className="text-[10px] font-black uppercase tracking-widest">Progress</span>
                      </button>
                      <button 
                        onClick={() => {
                          setShowPronunciationHistory(!showPronunciationHistory);
                          setShowPronunciationProgress(false);
                        }}
                        className={cn(
                          "flex items-center gap-2 px-4 py-2 rounded-2xl transition-all border",
                          showPronunciationHistory 
                            ? "bg-brand-pink/10 border-brand-pink/50 text-brand-pink" 
                            : "bg-brand-card/50 border-white/5 text-white/40 hover:text-white"
                        )}
                      >
                        <History className="w-4 h-4" />
                        <span className="text-[10px] font-black uppercase tracking-widest">History</span>
                      </button>
                    </div>
                  </div>

                  {isLoadingDrills ? (
                    <div className="flex-1 flex flex-col items-center justify-center gap-4">
                      <div className="w-12 h-12 border-4 border-brand-pink border-t-transparent rounded-full animate-spin" />
                      <p className="text-white/20 text-xs font-bold uppercase tracking-widest animate-pulse">Preparing drills...</p>
                    </div>
                  ) : showPronunciationProgress ? (
                    <div className="space-y-8 w-full">
                      {/* Stats Overview */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-2">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Average Score</p>
                          <p className="text-3xl font-black text-white">
                            {pronunciationHistory.length > 0 
                              ? Math.round(pronunciationHistory.reduce((acc, curr) => acc + curr.analysis.score, 0) / pronunciationHistory.length)
                              : 0}
                          </p>
                        </div>
                        <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-2">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Sessions</p>
                          <p className="text-3xl font-black text-white">{pronunciationHistory.length}</p>
                        </div>
                        <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-2">
                          <p className="text-[10px] font-bold uppercase tracking-widest text-white/20">Top Accuracy</p>
                          <p className="text-3xl font-black text-emerald-400">
                            {pronunciationHistory.length > 0 
                              ? Math.max(...pronunciationHistory.map(h => h.analysis.accuracy))
                              : 0}%
                          </p>
                        </div>
                      </div>

                      {/* Score Trend Chart */}
                      <div className="bg-brand-card/50 border border-white/5 p-8 rounded-[40px] space-y-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <TrendingUp className="w-4 h-4 text-brand-pink" />
                            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Performance Trend</span>
                          </div>
                        </div>
                        <div className="h-[300px] w-full">
                          {pronunciationHistory.length > 1 ? (
                            <ResponsiveContainer width="100%" height="100%">
                              <AreaChart data={pronunciationHistory.map(h => ({
                                date: new Date(h.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' }),
                                score: h.analysis.score,
                                accuracy: h.analysis.accuracy,
                                fluency: h.analysis.fluency
                              }))}>
                                <defs>
                                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#ff2d55" stopOpacity={0.3}/>
                                    <stop offset="95%" stopColor="#ff2d55" stopOpacity={0}/>
                                  </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                                <XAxis 
                                  dataKey="date" 
                                  stroke="#ffffff20" 
                                  fontSize={10} 
                                  tickLine={false}
                                  axisLine={false}
                                />
                                <YAxis 
                                  stroke="#ffffff20" 
                                  fontSize={10} 
                                  tickLine={false}
                                  axisLine={false}
                                  domain={[0, 100]}
                                />
                                <Tooltip 
                                  contentStyle={{ 
                                    backgroundColor: '#151619', 
                                    border: '1px solid rgba(255,255,255,0.05)',
                                    borderRadius: '12px',
                                    fontSize: '12px'
                                  }}
                                  itemStyle={{ color: '#fff' }}
                                />
                                <Area 
                                  type="monotone" 
                                  dataKey="score" 
                                  stroke="#ff2d55" 
                                  strokeWidth={3}
                                  fillOpacity={1} 
                                  fill="url(#colorScore)" 
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="accuracy" 
                                  stroke="#10b981" 
                                  strokeWidth={2}
                                  dot={false}
                                />
                                <Line 
                                  type="monotone" 
                                  dataKey="fluency" 
                                  stroke="#3b82f6" 
                                  strokeWidth={2}
                                  dot={false}
                                />
                              </AreaChart>
                            </ResponsiveContainer>
                          ) : (
                            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-20">
                              <TrendingUp className="w-12 h-12" />
                              <p className="text-xs font-bold uppercase tracking-widest">Complete more sessions to see trends</p>
                            </div>
                          )}
                        </div>
                        <div className="flex justify-center gap-6">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-brand-pink" />
                            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Overall Score</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-emerald-500" />
                            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Accuracy</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-blue-500" />
                            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Fluency</span>
                          </div>
                        </div>
                      </div>

                      {/* Improvement Areas */}
                      <div className="bg-brand-card/50 border border-white/5 p-8 rounded-[40px] space-y-6">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-brand-pink" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Focus Areas</span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {pronunciationHistory.length > 0 ? (
                            Array.from(new Set(pronunciationHistory.flatMap(h => h.analysis.improvements)))
                              .slice(0, 6)
                              .map((imp, i) => (
                                <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5">
                                  <div className="w-8 h-8 rounded-xl bg-brand-pink/10 flex items-center justify-center shrink-0">
                                    <span className="text-[10px] font-black text-brand-pink">{i + 1}</span>
                                  </div>
                                  <p className="text-xs text-white/60 font-medium leading-relaxed">{imp}</p>
                                </div>
                              ))
                          ) : (
                            <p className="text-white/20 text-xs font-bold uppercase tracking-widest text-center col-span-2 py-12">No data yet</p>
                          )}
                        </div>
                      </div>
                    </div>
                  ) : showPronunciationHistory ? (
                    <div className="space-y-4 w-full">
                      <div className="flex items-center justify-between px-2">
                        <div className="flex items-center gap-2">
                          <History className="w-3 h-3 text-brand-pink" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Past Sessions</span>
                        </div>
                        <button 
                          onClick={() => setPronunciationHistory([])}
                          className="text-[9px] font-bold text-white/10 hover:text-red-500/50 uppercase tracking-widest transition-colors"
                        >
                          Clear All
                        </button>
                      </div>
                      {pronunciationHistory.length === 0 ? (
                        <div className="text-center py-20 space-y-4 bg-brand-card/20 rounded-3xl border border-dashed border-white/5">
                          <History className="w-12 h-12 text-white/5 mx-auto" />
                          <p className="text-white/20 text-xs font-bold uppercase tracking-widest">No history yet</p>
                        </div>
                      ) : (
                        pronunciationHistory.map((item, i) => (
                          <motion.div
                            key={item.id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.05 }}
                            className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-4 hover:bg-brand-card transition-all group"
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-4">
                                <div className={cn(
                                  "w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-lg shadow-lg",
                                  item.analysis.score >= 80 ? "bg-emerald-500/20 text-emerald-400 shadow-emerald-500/10" :
                                  item.analysis.score >= 50 ? "bg-amber-500/20 text-amber-400 shadow-amber-500/10" :
                                  "bg-brand-pink/20 text-brand-pink shadow-brand-pink/10"
                                )}>
                                  {item.analysis.score}
                                </div>
                                <div className="text-left">
                                  <p className="text-sm font-bold text-white group-hover:text-brand-pink transition-colors line-clamp-1">"{item.sentence}"</p>
                                  <p className="text-[10px] text-white/20 uppercase tracking-widest font-bold mt-1">
                                    {new Date(item.timestamp).toLocaleDateString()} • {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                  </p>
                                </div>
                              </div>
                              <button 
                                onClick={() => {
                                  const drill = pronunciationDrills.find(d => d.sentence === item.sentence) || {
                                    sentence: item.sentence,
                                    focus: "Review",
                                    phonetic: "",
                                    tip: "Focus on the specific sounds that were highlighted in your previous feedback."
                                  };
                                  setCurrentDrill(drill);
                                  setPronunciationAnalysis(item.analysis);
                                  setShowPronunciationHistory(false);
                                }}
                                className="p-3 bg-white/5 text-white/20 rounded-xl hover:bg-brand-pink hover:text-white transition-all"
                              >
                                <ChevronRight className="w-4 h-4" />
                              </button>
                            </div>
                          </motion.div>
                        ))
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4 w-full">
                      {pronunciationDrills.map((drill, i) => (
                        <motion.button
                          key={i}
                          whileHover={{ x: 10 }}
                          onClick={() => {
                            setCurrentDrill(drill);
                            setPronunciationAnalysis(null);
                          }}
                          className="w-full bg-brand-card/50 border border-white/5 p-6 rounded-3xl text-left hover:bg-brand-card transition-all flex items-center justify-between group"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-3">
                              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-pink/60">{drill.focus}</span>
                              <span className="text-[10px] font-mono text-white/20">{drill.phonetic}</span>
                            </div>
                            <h3 className="text-lg font-bold text-white">{drill.sentence}</h3>
                          </div>
                          <ChevronRight className="w-5 h-5 text-white/20 group-hover:text-brand-pink transition-colors" />
                        </motion.button>
                      ))}
                    </div>
                  )}

                  <button 
                    onClick={fetchDrills}
                    className="mx-auto text-white/20 hover:text-white text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Refresh Drills
                  </button>
                </div>
              ) : (
                <div className="flex-1 flex flex-col p-6 space-y-8">
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={() => setCurrentDrill(null)}
                      className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-white/40 hover:text-white transition-colors"
                    >
                      <ChevronRight className="w-6 h-6 rotate-180" />
                    </button>
                    <div>
                      <h3 className="text-xl font-bold text-white">Pronunciation Practice</h3>
                      <p className="text-xs text-white/40 uppercase tracking-widest font-bold">{currentDrill.focus}</p>
                    </div>
                  </div>

                  <div className="bg-brand-card/50 border border-white/5 rounded-[40px] p-12 flex flex-col items-center text-center space-y-8 relative overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-brand-pink/20 to-transparent" />
                    
                    <div className="space-y-6">
                      <div className="flex items-center justify-center gap-4">
                        <p className="text-3xl md:text-4xl font-bold text-white tracking-tight leading-tight">
                          "{currentDrill.sentence}"
                        </p>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => speakText(currentDrill.sentence)}
                            className="p-3 bg-brand-pink/10 hover:bg-brand-pink/20 rounded-2xl text-brand-pink transition-all hover:scale-110 active:scale-95"
                            title="Listen to target pronunciation"
                          >
                            <Volume2 className="w-6 h-6" />
                          </button>
                          <div className="flex flex-col gap-2 min-w-[120px]">
                            <div className="flex items-center justify-between px-1">
                              <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Speed: {playbackSpeed}x</span>
                            </div>
                            <input 
                              type="range"
                              min="0.5"
                              max="2.0"
                              step="0.1"
                              value={playbackSpeed}
                              onChange={(e) => setPlaybackSpeed(parseFloat(e.target.value))}
                              className="w-full h-1.5 bg-white/5 rounded-lg appearance-none cursor-pointer accent-brand-pink hover:accent-brand-pink/80 transition-all"
                            />
                            <div className="flex justify-between px-1">
                              <span className="text-[8px] font-bold text-white/10">0.5x</span>
                              <span className="text-[8px] font-bold text-white/10">1.0x</span>
                              <span className="text-[8px] font-bold text-white/10">2.0x</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-center gap-2">
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-white/20">Phonetic Guide</span>
                        <p className="text-xl font-mono text-brand-pink/80 bg-brand-pink/5 px-6 py-2 rounded-full border border-brand-pink/10">
                          {currentDrill.phonetic}
                        </p>
                      </div>

                      <div className="space-y-4 max-w-lg mx-auto">
                        <div className="flex items-center justify-center gap-2">
                          <Zap className="w-3 h-3 text-brand-pink" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/20">Practice Tip</span>
                        </div>
                        <p className="text-sm text-white/60 leading-relaxed bg-white/5 p-4 rounded-2xl border border-white/5 italic">
                          {currentDrill.tip}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-col items-center gap-6">
                      <div className="relative">
                        {isRecording && (
                          <motion.div 
                            animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                            transition={{ duration: 2, repeat: Infinity }}
                            className="absolute inset-0 bg-brand-pink rounded-full blur-2xl"
                          />
                        )}
                        <button
                          onClick={() => setIsRecording(!isRecording)}
                          className={cn(
                            "relative w-24 h-24 rounded-full flex items-center justify-center transition-all duration-500",
                            "bg-gradient-to-br from-brand-pink to-brand-purple shadow-xl",
                            "hover:scale-105 active:scale-95",
                            isRecording && "scale-110 shadow-[0_0_40px_rgba(255,45,85,0.4)]"
                          )}
                        >
                          {isRecording ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
                        </button>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm text-white/40 font-medium">
                          {isRecording ? "Listening..." : "Tap to record your pronunciation"}
                        </p>
                        {isRecording && transcript && (
                          <motion.p 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-xs text-brand-pink font-bold animate-pulse"
                          >
                            "{transcript}..."
                          </motion.p>
                        )}
                      </div>
                    </div>

                    <AnimatePresence>
                      {isAnalyzingPronunciation && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                          className="flex flex-col items-center gap-3"
                        >
                          <div className="w-8 h-8 border-2 border-brand-pink border-t-transparent rounded-full animate-spin" />
                          <p className="text-xs font-bold uppercase tracking-widest text-white/40">Analyzing speech...</p>
                        </motion.div>
                      )}

                      {pronunciationAnalysis && (
                        <motion.div 
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="w-full space-y-4"
                        >
                          {/* Main Result Card */}
                          <div className="bg-brand-card/80 border border-white/10 rounded-[32px] p-8 backdrop-blur-md relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                              <Sparkles className="w-32 h-32 text-brand-pink" />
                            </div>
                            
                            <div className="flex flex-col md:flex-row items-center gap-8 relative z-10">
                              <div className="relative shrink-0">
                                <svg className="w-32 h-32 transform -rotate-90">
                                  <circle
                                    cx="64"
                                    cy="64"
                                    r="58"
                                    stroke="currentColor"
                                    strokeWidth="8"
                                    fill="transparent"
                                    className="text-white/5"
                                  />
                                  <motion.circle
                                    cx="64"
                                    cy="64"
                                    r="58"
                                    stroke="currentColor"
                                    strokeWidth="8"
                                    fill="transparent"
                                    strokeDasharray={364.4}
                                    initial={{ strokeDashoffset: 364.4 }}
                                    animate={{ strokeDashoffset: 364.4 - (364.4 * pronunciationAnalysis.score) / 100 }}
                                    transition={{ duration: 1.5, ease: "easeOut" }}
                                    className={cn(
                                      pronunciationAnalysis.score >= 80 ? "text-emerald-500" :
                                      pronunciationAnalysis.score >= 50 ? "text-amber-500" :
                                      "text-brand-pink"
                                    )}
                                  />
                                </svg>
                                <div className="absolute inset-0 flex flex-col items-center justify-center">
                                  <span className="text-3xl font-black text-white">{pronunciationAnalysis.score}</span>
                                  <span className="text-[8px] font-bold text-white/20 uppercase tracking-widest">Score</span>
                                </div>
                              </div>

                              <div className="flex-1 text-center md:text-left space-y-4">
                                <div className="space-y-1">
                                  <h4 className="text-xl font-bold text-white">
                                    {pronunciationAnalysis.score >= 90 ? "Excellent! 🌟" :
                                     pronunciationAnalysis.score >= 80 ? "Great Job! 👍" :
                                     pronunciationAnalysis.score >= 60 ? "Good Effort! 💪" :
                                     "Keep Practicing! 🎯"}
                                  </h4>
                                  <p className="text-sm text-white/60 leading-relaxed">
                                    {pronunciationAnalysis.feedback}
                                  </p>
                                </div>
                                
                                {pronunciationAnalysis.userTranscript && (
                                  <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/5 rounded-xl border border-white/5">
                                    <span className="text-[9px] font-black text-white/20 uppercase tracking-widest">Heard:</span>
                                    <span className="text-xs text-white/40 italic">"{pronunciationAnalysis.userTranscript}"</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Bento Grid Metrics */}
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl flex flex-col items-center justify-center gap-2 group hover:bg-brand-card transition-colors">
                              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500 group-hover:scale-110 transition-transform">
                                <Target className="w-5 h-5" />
                              </div>
                              <div className="text-center">
                                <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Accuracy</p>
                                <p className="text-xl font-black text-white">{pronunciationAnalysis.accuracy}%</p>
                              </div>
                            </div>
                            
                            <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl flex flex-col items-center justify-center gap-2 group hover:bg-brand-card transition-colors">
                              <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                                <Activity className="w-5 h-5" />
                              </div>
                              <div className="text-center">
                                <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Fluency</p>
                                <p className="text-xl font-black text-white">{pronunciationAnalysis.fluency}%</p>
                              </div>
                            </div>

                            <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl flex flex-col items-center justify-center gap-2 group hover:bg-brand-card transition-colors">
                              <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-500 group-hover:scale-110 transition-transform">
                                <CheckCircle2 className="w-5 h-5" />
                              </div>
                              <div className="text-center">
                                <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Completeness</p>
                                <p className="text-xl font-black text-white">{pronunciationAnalysis.completeness}%</p>
                              </div>
                            </div>
                          </div>

                          {/* Improvements & Actions */}
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl space-y-4">
                              <div className="flex items-center gap-2">
                                <Zap className="w-4 h-4 text-brand-pink" />
                                <span className="text-[10px] font-black uppercase tracking-widest text-white/20">Points to improve</span>
                              </div>
                              <div className="space-y-2">
                                {pronunciationAnalysis.improvements.length > 0 ? (
                                  pronunciationAnalysis.improvements.map((imp, i) => (
                                    <div key={i} className="flex items-start gap-3 bg-white/5 p-3 rounded-xl border border-white/5">
                                      <div className="w-1.5 h-1.5 bg-brand-pink rounded-full mt-1.5 shrink-0" />
                                      <p className="text-xs text-white/60 leading-relaxed">{imp}</p>
                                    </div>
                                  ))
                                ) : (
                                  <p className="text-xs text-white/20 italic">No specific improvements needed. Excellent!</p>
                                )}
                              </div>
                            </div>

                            <div className="flex flex-col gap-3">
                              <button 
                                onClick={() => setPronunciationAnalysis(null)}
                                className="flex-1 bg-brand-pink text-white rounded-3xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-brand-pink/90 transition-all hover:scale-[1.02] active:scale-[0.98] shadow-lg shadow-brand-pink/20"
                              >
                                <RotateCcw className="w-4 h-4" />
                                Try Again
                              </button>
                              <button 
                                onClick={() => {
                                  const currentIndex = pronunciationDrills.findIndex(d => d.sentence === currentDrill.sentence);
                                  const nextDrill = pronunciationDrills[(currentIndex + 1) % pronunciationDrills.length];
                                  setCurrentDrill(nextDrill);
                                  setPronunciationAnalysis(null);
                                }}
                                className="flex-1 bg-white/5 text-white border border-white/10 rounded-3xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/10 transition-all hover:scale-[1.02] active:scale-[0.98]"
                              >
                                Next Drill
                                <ChevronRight className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div 
              key="chat"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col h-[70vh] bg-white/5 border border-white/10 rounded-3xl overflow-hidden backdrop-blur-xl"
            >
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-brand-card/30">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-brand-pink rounded-full flex items-center justify-center">
                    <Volume2 className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Conversation Partner</h3>
                    <select 
                      value={selectedScenario || ''}
                      onChange={(e) => setSelectedScenario(e.target.value || null)}
                      className="bg-black/20 border border-white/10 rounded-lg px-2 py-0.5 text-[10px] text-white/70 focus:outline-none focus:border-brand-pink/50"
                    >
                      <option value="">Casual Conversation</option>
                      <option value="Job Interview">Job Interview</option>
                      <option value="Ordering Food">Ordering Food</option>
                      <option value="Travel">Travel</option>
                    </select>
                  </div>
                </div>
                <button onClick={reset} className="text-white/40 hover:text-white transition-colors">
                  <RotateCcw className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-hide">
                {chatHistory.length === 0 && (
                  <div className="h-full flex flex-col items-center justify-center p-6 space-y-8">
                    <div className="text-center space-y-2 opacity-40">
                      <MessageSquare className="w-12 h-12 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-white">Start a Conversation</h3>
                      <p className="text-sm text-white/60">Choose a topic below or just start speaking</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-2xl">
                      {CONVERSATION_STARTERS.map((starter, i) => (
                        <motion.button
                          key={i}
                          whileHover={{ scale: 1.02, x: 5 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => {
                            setManualInput(starter.text);
                            processInput(starter.text);
                            setManualInput('');
                          }}
                          className="bg-brand-card/50 border border-white/5 p-6 rounded-3xl text-left hover:bg-brand-card hover:border-brand-pink/20 transition-all group relative overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Sparkles className="w-4 h-4 text-brand-pink" />
                          </div>
                          <p className="text-[10px] font-bold text-brand-pink/60 uppercase tracking-widest mb-1 group-hover:text-brand-pink transition-colors">{starter.label}</p>
                          <p className="text-sm text-white/60 group-hover:text-white transition-colors leading-relaxed">{starter.text}</p>
                        </motion.button>
                      ))}
                    </div>
                  </div>
                )}
                {chatHistory.map((msg, i) => (
                  <motion.div 
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={cn(
                      "max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed",
                      msg.role === 'user' 
                        ? "ml-auto bg-brand-pink text-white rounded-tr-none" 
                        : "mr-auto bg-brand-card text-white/90 rounded-tl-none border border-white/5"
                    )}
                  >
                    {msg.text}
                  </motion.div>
                ))}
                {isRecording && transcript && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="ml-auto max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed bg-brand-pink/50 text-white/80 rounded-tr-none border border-brand-pink/20 italic"
                  >
                    {transcript}...
                  </motion.div>
                )}
                {isLoading && (
                  <div className="mr-auto bg-brand-card p-4 rounded-2xl rounded-tl-none border border-white/5 flex gap-1">
                    {[1, 2, 3].map(i => (
                      <motion.div 
                        key={i}
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                        className="w-1.5 h-1.5 bg-white/40 rounded-full"
                      />
                    ))}
                  </div>
                )}
              </div>

              <div className="p-4 bg-black/40 border-t border-white/10 backdrop-blur-md">
                <div className="max-w-2xl mx-auto flex items-center gap-3">
                  <button
                    onClick={() => setIsRecording(!isRecording)}
                    className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 shrink-0",
                      isRecording ? "bg-brand-pink animate-pulse shadow-lg shadow-brand-pink/20" : "bg-white/5 hover:bg-white/10 text-white/60 hover:text-white border border-white/10"
                    )}
                  >
                    {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                  
                  <form 
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (manualInput.trim()) {
                        processInput(manualInput);
                        setManualInput('');
                      }
                    }}
                    className="flex-1 relative group"
                  >
                    <input 
                      type="text"
                      value={manualInput}
                      onChange={(e) => setManualInput(e.target.value)}
                      placeholder="Type a message..."
                      className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3 pr-12 text-sm focus:outline-none focus:border-red-500/50 focus:bg-white/10 transition-all"
                    />
                    <button 
                      type="submit"
                      disabled={!manualInput.trim()}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-red-500 hover:text-red-400 disabled:text-white/10 transition-colors"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </form>
                </div>
                <div className="mt-2 text-center">
                  <p className="text-[10px] uppercase tracking-widest text-white/20 font-bold">Press Enter to send</p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 p-8 bg-red-900/10 border border-red-500/20 rounded-3xl text-red-400 flex flex-col items-center gap-6 backdrop-blur-xl"
          >
            <div className="w-12 h-12 bg-red-500/20 rounded-full flex items-center justify-center">
              <MicOff className="w-6 h-6" />
            </div>
            
            <div className="space-y-2 text-center">
              <h3 className="text-xl font-bold text-white">Microphone Access Required</h3>
              <p className="text-white/60 max-w-md mx-auto leading-relaxed">
                {error}
              </p>
              {permissionStatus === 'denied' && (
                <div className="mt-4 p-4 bg-black/40 rounded-2xl text-xs text-left space-y-3 border border-white/5">
                  <p className="font-bold text-brand-pink uppercase tracking-widest">How to fix:</p>
                  <ol className="list-decimal list-inside space-y-2 text-white/40">
                    <li>Click the <span className="text-white font-medium">lock icon</span> (🔒) in your browser's address bar.</li>
                    <li>Find <span className="text-white font-medium">Microphone</span> and toggle it <span className="text-emerald-500 font-bold">ON</span>.</li>
                    <li>Refresh this page and try again.</li>
                  </ol>
                </div>
              )}
            </div>

            <div className="flex gap-4">
              {permissionStatus !== 'denied' && (
                <button 
                  onClick={requestPermission}
                  className="px-8 py-3 bg-brand-pink text-white rounded-full font-bold hover:bg-brand-purple transition-all shadow-xl shadow-brand-pink/40 active:scale-95"
                >
                  Request Access
                </button>
              )}
              <button 
                onClick={reset}
                className="px-8 py-3 bg-white/5 text-white/60 rounded-full font-bold hover:bg-white/10 transition-all active:scale-95"
              >
                Dismiss
              </button>
            </div>

            <p className="text-[10px] uppercase tracking-widest text-white/20 font-bold">
              Current Status: <span className={cn(
                permissionStatus === 'granted' ? "text-emerald-500" : 
                permissionStatus === 'denied' ? "text-brand-pink" : "text-amber-500"
              )}>{permissionStatus}</span>
            </p>
          </motion.div>
        )}
        </div>
      </main>
      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-brand-bg/80 backdrop-blur-2xl border-t border-white/5 px-4 py-3 flex items-center justify-around">
        <button 
          onClick={() => { setMode('coach'); reset(); }}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            mode === 'coach' ? "text-brand-pink" : "text-white/20"
          )}
        >
          <Sparkles className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Coach</span>
        </button>
        <button 
          onClick={() => { setMode('chat'); reset(); }}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            mode === 'chat' ? "text-brand-pink" : "text-white/20"
          )}
        >
          <MessageSquare className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Chat</span>
        </button>
        <button 
          onClick={() => { setMode('exercise'); reset(); }}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            mode === 'exercise' ? "text-brand-pink" : "text-white/20"
          )}
        >
          <Play className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Exercise</span>
        </button>
        <button 
          onClick={() => { setMode('vocabulary'); reset(); }}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            mode === 'vocabulary' ? "text-brand-pink" : "text-white/20"
          )}
        >
          <BookOpen className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Words</span>
        </button>
        <button 
          onClick={() => { setMode('pronunciation'); reset(); }}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            mode === 'pronunciation' ? "text-brand-pink" : "text-white/20"
          )}
        >
          <Volume2 className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Speak</span>
        </button>
        <button 
          onClick={() => setShowGoalsProgress(true)}
          className={cn(
            "flex flex-col items-center gap-1 transition-all",
            showGoalsProgress ? "text-brand-pink" : "text-white/20"
          )}
        >
          <Activity className="w-6 h-6" />
          <span className="text-[9px] font-black uppercase tracking-widest">Stats</span>
        </button>
      </nav>
    </div>
  );
}
